# Universal 3DS 3D Game Template

A complete, self-contained Nintendo 3DS project ready to compile locally or automatically via GitHub Actions.

## Included:
- **Pre-configured GitHub Action**: Automatically compiles `.3dsx` on push!
- **`icon.png` (48x48)**: Integrated home menu icon.
- **`romfs/`**: Contains runtime assets (`meepa_character.obj`, `meepa_texture.png`).
- **`source/main.c`**: Full game loop with Circle Pad controls, dynamic hover physics, and 3D rendering.
- **`Makefile`**: Standard devkitARM rules, SMDH builder, and proper linking order.

## How to use on GitHub:
1. Upload these files to any GitHub repository.
2. The Action will automatically run and output your `.3dsx` in the Artifacts tab!
