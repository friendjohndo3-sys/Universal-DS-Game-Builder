#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define CLEAR_COLOR 0x68B0D8FF // Sky blue background

typedef struct {
    float x, y, z;
} Vec3;

typedef struct {
    float u, v;
} TexCoord;

typedef struct {
    int v_idx[4];
    int vt_idx[4];
    int vn_idx[4];
    int count;
} ObjFace;

#define MAX_VERTS 200
#define MAX_UVS   200
#define MAX_NORMS 200
#define MAX_FACES 300

static Vec3 s_vertices[MAX_VERTS];
static TexCoord s_uvs[MAX_UVS];
static Vec3 s_normals[MAX_NORMS];
static ObjFace s_faces[MAX_FACES];

static int s_vert_count = 0;
static int s_uv_count = 0;
static int s_norm_count = 0;
static int s_face_count = 0;

void load_meepa_obj(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) {
        printf("Failed to open %s!\n", path);
        return;
    }

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "v ", 2) == 0) {
            Vec3 v;
            if (sscanf(line + 2, "%f %f %f", &v.x, &v.y, &v.z) == 3) {
                if (s_vert_count < MAX_VERTS) s_vertices[s_vert_count++] = v;
            }
        } else if (strncmp(line, "vt ", 3) == 0) {
            TexCoord vt;
            if (sscanf(line + 3, "%f %f", &vt.u, &vt.v) == 2) {
                if (s_uv_count < MAX_UVS) s_uvs[s_uv_count++] = vt;
            }
        } else if (strncmp(line, "vn ", 3) == 0) {
            Vec3 vn;
            if (sscanf(line + 3, "%f %f %f", &vn.x, &vn.y, &vn.z) == 3) {
                if (s_norm_count < MAX_NORMS) s_normals[s_norm_count++] = vn;
            }
        } else if (strncmp(line, "f ", 2) == 0) {
            ObjFace face;
            memset(&face, 0, sizeof(face));
            char* token = strtok(line + 2, " \r\n");
            int c = 0;
            while (token && c < 4) {
                int vi = 0, vti = 0, vni = 0;
                if (sscanf(token, "%d/%d/%d", &vi, &vti, &vni) >= 1) {
                    face.v_idx[c] = vi - 1;
                    face.vt_idx[c] = vti - 1;
                    face.vn_idx[c] = vni - 1;
                    c++;
                }
                token = strtok(NULL, " \r\n");
            }
            face.count = c;
            if (s_face_count < MAX_FACES) s_faces[s_face_count++] = face;
        }
    }
    fclose(f);
}

int main(int argc, char* argv[]) {
    gfxInitDefault();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    consoleInit(GFX_BOTTOM, NULL);
    printf("\x1b[1;1H=================================");
    printf("\x1b[2;1H       MEEPA 3DS ADVENTURE       ");
    printf("\x1b[3;1H=================================");
    printf("\x1b[5;1H[CONTROLS]");
    printf("\x1b[6;1H- Circle Pad / D-Pad: Move Meepa");
    printf("\x1b[7;1H- A Button: Float / Jump");
    printf("\x1b[8;1H- L / R Triggers: Rotate Character");
    printf("\x1b[9;1H- START: Exit to Homebrew Menu");

    load_meepa_obj("romfs:/meepa_character.obj");
    printf("\x1b[12;1HLoaded Mesh: %d Verts, %d Faces", s_vert_count, s_face_count);

    C3D_RenderTarget* topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);

    float playerX = 200.0f;
    float playerY = 120.0f;
    float floatOffset = 0.0f;
    float rotation = 0.0f;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();

        if (kDown & KEY_START) break;

        circlePosition cpos;
        hidCircleRead(&cpos);
        playerX += (float)cpos.dx / 35.0f;
        playerY -= (float)cpos.dy / 35.0f;

        if (kHeld & KEY_DLEFT)  playerX -= 2.0f;
        if (kHeld & KEY_DRIGHT) playerX += 2.0f;
        if (kHeld & KEY_DUP)    playerY -= 2.0f;
        if (kHeld & KEY_DDOWN)  playerY += 2.0f;

        if (kHeld & KEY_L) rotation -= 0.05f;
        if (kHeld & KEY_R) rotation += 0.05f;

        floatOffset = sinf(osGetTime() / 250.0f) * 6.0f;

        if (playerX < 30.0f) playerX = 30.0f;
        if (playerX > 370.0f) playerX = 370.0f;
        if (playerY < 30.0f) playerY = 30.0f;
        if (playerY > 210.0f) playerY = 210.0f;

        printf("\x1b[14;1HPosition: X: %0.1f | Y: %0.1f   ", playerX, playerY);
        printf("\x1b[15;1HRotation: %0.2f rad            ", rotation);

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(topTarget, C2D_Color32(104, 176, 216, 255));
        C2D_SceneBegin(topTarget);

        // Ground shadow
        C2D_DrawEllipseSolid(playerX, playerY + 36.0f, 0.0f, 28.0f, 10.0f, C2D_Color32(70, 130, 160, 180));

        // 3D Meepa Wireframe/Polygons
        float scale = 32.0f;
        for (int i = 0; i < s_face_count; i++) {
            ObjFace* f = &s_faces[i];
            if (f->count < 3) continue;

            float sx[4], sy[4];
            for (int j = 0; j < f->count; j++) {
                Vec3 v = s_vertices[f->v_idx[j]];
                float rx = v.x * cosf(rotation) + v.z * sinf(rotation);
                float ry = v.y;

                sx[j] = playerX + rx * scale;
                sy[j] = (playerY + floatOffset) - ry * scale;
            }

            u32 faceColor = C2D_Color32(255, 255, 255, 255);
            if (i > 70) faceColor = C2D_Color32(235, 235, 240, 255);
            
            C2D_DrawTriangle(sx[0], sy[0], faceColor,
                             sx[1], sy[1], faceColor,
                             sx[2], sy[2], faceColor, 0.0f);
            if (f->count == 4) {
                C2D_DrawTriangle(sx[0], sy[0], faceColor,
                                 sx[2], sy[2], faceColor,
                                 sx[3], sy[3], faceColor, 0.0f);
            }
        }

        // Face (:3)
        if (cosf(rotation) > -0.2f) {
            float fx = playerX + sinf(rotation) * 8.0f;
            float fy = playerY + floatOffset;

            C2D_DrawRectSolid(fx - 12.0f, fy - 6.0f, 0.0f, 4.0f, 4.0f, C2D_Color32(20, 20, 20, 255));
            C2D_DrawRectSolid(fx + 8.0f, fy - 6.0f, 0.0f, 4.0f, 4.0f, C2D_Color32(20, 20, 20, 255));

            C2D_DrawRectSolid(fx - 4.0f, fy + 4.0f, 0.0f, 3.0f, 3.0f, C2D_Color32(20, 20, 20, 255));
            C2D_DrawRectSolid(fx - 1.0f, fy + 6.0f, 0.0f, 3.0f, 3.0f, C2D_Color32(20, 20, 20, 255));
            C2D_DrawRectSolid(fx + 2.0f, fy + 4.0f, 0.0f, 3.0f, 3.0f, C2D_Color32(20, 20, 20, 255));
        }

        C3D_FrameEnd(0);
    }

    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
