# Monster Truck Mayhem! (Nintendo 3DS - 2011 Edition)

A complete 3D Monster Truck Stadium Racing & Freestyle Stunt Show game for the Nintendo 3DS / 2DS, built with `libctru`, `citro3d`, and `citro2d`.

---

## Features Included
- **Low-Poly 3D Monster Trucks (`romfs:/monster_truck.obj`)**:
  - 3 Playable Monster Trucks with distinct stats and liveries:
    1. **INFERNO REX** (Flame Red / Gold Beadlock Rims)
    2. **GRAVE CRUSHER** (Midnight Purple / Toxic Green Frame)
    3. **NITRO BULLDOZER** (Construction Yellow / Chrome Rollcage)
- **2 Full Game Modes**:
  - **Championship Racing**: 3-Lap head-to-head stadium race against AI monster trucks with live position tracking and lap radar.
  - **Freestyle Stunt Show**: 90-second timed stunt arena—pull wheelies, launch off dirt ramps, perform mid-air 360 backflips, and crush rows of junk cars for combo multipliers!
- **3 Distinct Stadium Tracks**:
  1. **Thunder Dome Arena** (Indoor Mud Oval & Freestyle Crush Cars)
  2. **Baja Canyon Run** (High-Speed Desert Dirt Jumps & Mesas)
  3. **Frostbite Stadium** (Icy Snow Drifts & Mega Steel Ramps)
- **Full 2011 Dual-Screen Menu & UI System**:
  - Splash Screen, 3D Rotating Showroom Turntable, Monster Garage, Track Selection, Options Page (Music toggle, SFX toggle, 3D Camera distance, AI Difficulty), Controls Manual, and Loading Screens.
- **Custom Heavy Metal / Industrial Audio Track (`romfs:/mayhem_theme.raw` & `.wav`)**:
  - Built-in Drop-D power-chord guitar & drum loop streamed via 3DS NDSP hardware audio.

---

## Controls (Buttons & Touchscreen)
- **A Button / Touch `GAS`**: Throttle / Accelerate
- **B Button**: Brakes & Reverse
- **Circle Pad / D-Pad Left & Right**: Steer Monster Truck (with 4-link suspension body roll)
- **R Button / X Button / Touch `NITRO`**: Flame Nitro Boost
- **L Button / Y Button / Touch `WHEELIE`**: Pull Monster Wheelie on ground / Perform 360 Backflips in mid-air
- **START**: Return to Home Menu / Exit to Homebrew Launcher
