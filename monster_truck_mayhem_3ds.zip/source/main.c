#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TOP_W 400
#define TOP_H 240
#define BOT_W 320
#define BOT_H 240

// Game States (2011 3DS Menu Architecture)
typedef enum {
    STATE_SPLASH = 0,
    STATE_HOME_MENU,
    STATE_GARAGE_SELECT,
    STATE_TRACK_SELECT,
    STATE_OPTIONS,
    STATE_CONTROLS_HELP,
    STATE_LOADING,
    STATE_GAMEPLAY,
    STATE_RESULTS
} GameState;

// Game Modes
typedef enum {
    MODE_CHAMPIONSHIP_RACE = 0,
    MODE_FREESTYLE_SHOW    = 1
} GameMode;

// 3D Math & Mesh Structures
typedef struct { float x, y, z; } Vec3;
typedef struct {
    int v[4];
    int group; // Texture/Material UV group
    float avg_z;
} FaceQuad;

#define MAX_VERTS 512
#define MAX_FACES 512
static Vec3 s_mesh_verts[MAX_VERTS];
static FaceQuad s_mesh_faces[MAX_FACES];
static int s_vert_count = 0;
static int s_face_count = 0;

// Texture Palette sampled from romfs:/truck_tex.png or 2011 Livery presets
typedef struct {
    const char* name;
    u32 body_col;
    u32 glass_col;
    u32 frame_col;
    u32 tire_col;
    u32 rim_col;
    float top_speed;
    float accel;
    float suspension_stiffness;
} TruckPreset;

static TruckPreset s_trucks[3] = {
    {
        "INFERNO REX",
        0xE6281EFF, // Flame Red
        0x38B6FFFF, // Tinted Blue Glass
        0xD8DCE6FF, // Chrome Rollcage
        0x262428FF, // Mud Tire Rubber
        0xF0C814FF, // Gold Beadlock Rim
        1.85f, 0.045f, 0.12f
    },
    {
        "GRAVE CRUSHER",
        0x5A189AFF, // Midnight Purple
        0x50FF78FF, // Toxic Green Glass
        0x9098A6FF, // Gunmetal Frame
        0x222225FF, // Heavy Tread
        0x50FF78FF, // Neon Green Rim
        1.78f, 0.052f, 0.14f
    },
    {
        "NITRO BULLDOZER",
        0xFFAA00FF, // Construction Yellow
        0x30A0E0FF, // Ice Glass
        0xE0E5F0FF, // Polished Chrome
        0x28262AFF, // Mud Tire
        0xFF3C1EFF, // Red Rim
        1.92f, 0.040f, 0.11f
    }
};

// Track / Arena Definitions
typedef struct {
    const char* title;
    const char* subtitle;
    u32 sky_top;
    u32 sky_horizon;
    u32 ground_primary;
    u32 ground_secondary;
    u32 barrier_col;
    float length;
    int ramp_count;
} TrackInfo;

static TrackInfo s_tracks[3] = {
    {
        "THUNDER DOME ARENA",
        "Indoor Mud Oval & Freestyle Crush Cars",
        0x141224FF, 0x2E2448FF,
        0x5E3C22FF, 0x4E301AFF,
        0xD82828FF,
        1400.0f, 10
    },
    {
        "BAJA CANYON RUN",
        "High-Speed Desert Dirt Jumps & Mesas",
        0x1E68B8FF, 0xE89850FF,
        0xC27D38FF, 0xA8682AFF,
        0xF0A818FF,
        1800.0f, 14
    },
    {
        "FROSTBITE STADIUM",
        "Icy Snow Drifts & Mega Steel Ramps",
        0x0F203CFF, 0x4878A8FF,
        0xC8DCF0FF, 0xA8C4E0FF,
        0x2088E8FF,
        1600.0f, 12
    }
};

// Ramp / Crushable Car Obstacle in 3D World
typedef struct {
    float x, z;
    float width, length, height;
    int type; // 0 = Dirt Launch Ramp, 1 = Crushable Junk Car Row, 2 = Bonus Star Ring
    int crushed;
} WorldProp;

#define MAX_PROPS 24
static WorldProp s_props[MAX_PROPS];

// Monster Truck Physics Vehicle State
typedef struct {
    float x, y, z;
    float vx, vy, vz;
    float speed;
    float heading;
    float pitch;       // Nose up/down angle (wheelies & jumps)
    float pitch_vel;
    float roll;        // Chassis body roll on turns
    float susp_offset; // 4-link suspension bounce
    float susp_vel;
    float nitro;
    int airborne;
    float air_time;
    int flip_accum;
    int lap;
    int truck_id;
} MonsterTruck;

// Particle System (Mud Rooster Tails, Nitro Flames, Car Crush Sparks)
typedef struct {
    float x, y, z;
    float vx, vy, vz;
    u32 color;
    int life;
} Particle3D;

#define MAX_PARTICLES 80
static Particle3D s_particles[MAX_PARTICLES];

// Global App Settings & State
static GameState s_state = STATE_SPLASH;
static GameState s_next_state = STATE_HOME_MENU;
static GameMode  s_mode  = MODE_CHAMPIONSHIP_RACE;
static int s_selected_truck = 0;
static int s_selected_track = 0;
static int s_menu_cursor = 0;
static int s_load_timer = 0;
static int s_splash_timer = 0;

// Options
static int s_opt_music_on = 1;
static int s_opt_sfx_on = 1;
static int s_opt_camera_dist = 1; // 0=Close, 1=Normal, 2=Far
static int s_opt_difficulty = 1;  // 0=Rookie, 1=Pro, 2=Mayhem

// Gameplay Entities
static MonsterTruck s_player;
static MonsterTruck s_ai[2];
static int s_stunt_score = 0;
static int s_combo_mult = 1;
static int s_combo_timer = 0;
static const char* s_last_stunt_name = "READY TO ROLL!";
static float s_race_timer = 0.0f;
static float s_show_timer = 90.0f; // 90 seconds freestyle show clock
static int s_player_rank = 1;

// Audio Buffer (ndsp / CSND fallback via ROMFS PCM)
static u8* s_audio_buf = NULL;
static u32 s_audio_size = 0;
static ndspWaveBuf s_wave_buf;
static int s_ndsp_ready = 0;

// Load Low-Poly Monster Truck OBJ from RomFS
static void load_truck_obj(const char* filepath) {
    s_vert_count = 0;
    s_face_count = 0;
    FILE* f = fopen(filepath, "r");
    if (!f) return;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "v ", 2) == 0) {
            Vec3 v;
            if (sscanf(line + 2, "%f %f %f", &v.x, &v.y, &v.z) == 3) {
                if (s_vert_count < MAX_VERTS) s_mesh_verts[s_vert_count++] = v;
            }
        } else if (strncmp(line, "f ", 2) == 0) {
            int v1=1, t1=1, n1=1, v2=1, t2=1, n2=1, v3=1, t3=1, n3=1, v4=1, t4=1, n4=1;
            int matches = sscanf(line + 2, "%d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d",
                                 &v1, &t1, &n1, &v2, &t2, &n2, &v3, &t3, &n3, &v4, &t4, &n4);
            if (matches >= 9 && s_face_count < MAX_FACES) {
                FaceQuad fq;
                fq.v[0] = v1 - 1;
                fq.v[1] = v2 - 1;
                fq.v[2] = v3 - 1;
                fq.v[3] = (matches == 12) ? (v4 - 1) : (v3 - 1);
                fq.group = (t1 - 1) % 5;
                fq.avg_z = 0.0f;
                s_mesh_faces[s_face_count++] = fq;
            }
        }
    }
    fclose(f);
}

// Initialize NDSP Audio and stream romfs:/mayhem_theme.raw in loop
static void init_game_audio(void) {
    FILE* f = fopen("romfs:/mayhem_theme.raw", "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END);
    s_audio_size = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (s_audio_size > 0) {
        s_audio_buf = (u8*)linearAlloc(s_audio_size);
        if (s_audio_buf) {
            fread(s_audio_buf, 1, s_audio_size, f);
            DSP_FlushDataCache(s_audio_buf, s_audio_size);
        }
    }
    fclose(f);

    if (s_audio_buf && R_SUCCEEDED(ndspInit())) {
        s_ndsp_ready = 1;
        ndspSetOutputMode(NDSP_OUTPUT_MONO);
        ndspChnReset(0);
        ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
        ndspChnSetRate(0, 22050.0f);
        ndspChnSetFormat(0, NDSP_FORMAT_MONO_PCM16);

        memset(&s_wave_buf, 0, sizeof(s_wave_buf));
        s_wave_buf.data_vaddr = s_audio_buf;
        s_wave_buf.nsamples = s_audio_size / 2;
        s_wave_buf.looping = true;
        ndspChnWaveBufAdd(0, &s_wave_buf);
    }
}

static void cleanup_game_audio(void) {
    if (s_ndsp_ready) {
        ndspChnReset(0);
        ndspExit();
    }
    if (s_audio_buf) {
        linearFree(s_audio_buf);
        s_audio_buf = NULL;
    }
}

static void spawn_world_particles(float x, float y, float z, u32 col, int count) {
    for (int i = 0; i < MAX_PARTICLES && count > 0; i++) {
        if (s_particles[i].life <= 0) {
            s_particles[i].x = x + ((rand() % 100) - 50) * 0.01f;
            s_particles[i].y = y;
            s_particles[i].z = z + ((rand() % 100) - 50) * 0.01f;
            s_particles[i].vx = ((rand() % 100) - 50) * 0.008f;
            s_particles[i].vy = 0.08f + ((rand() % 100) * 0.002f);
            s_particles[i].vz = -0.15f - ((rand() % 100) * 0.002f);
            s_particles[i].color = col;
            s_particles[i].life = 12 + (rand() % 14);
            count--;
        }
    }
}

// Build Arena / Track Obstacles
static void init_race_session(void) {
    memset(&s_player, 0, sizeof(s_player));
    s_player.truck_id = s_selected_truck;
    s_player.nitro = 100.0f;
    s_player.lap = 1;

    for (int i = 0; i < 2; i++) {
        memset(&s_ai[i], 0, sizeof(MonsterTruck));
        s_ai[i].truck_id = (s_selected_truck + i + 1) % 3;
        s_ai[i].x = (i == 0) ? -4.2f : 4.2f;
        s_ai[i].z = 6.0f + i * 4.0f;
        s_ai[i].lap = 1;
    }

    s_stunt_score = 0;
    s_combo_mult = 1;
    s_combo_timer = 0;
    s_race_timer = 0.0f;
    s_show_timer = 90.0f;
    s_last_stunt_name = (s_mode == MODE_FREESTYLE_SHOW) ? "HIT RAMPS & CRUSH CARS!" : "FULL THROTTLE RACE!";

    // Populate Ramps & Crushable Cars along the track
    float track_len = s_tracks[s_selected_track].length;
    for (int i = 0; i < MAX_PROPS; i++) {
        s_props[i].z = 55.0f + (track_len / MAX_PROPS) * i;
        int lane = (i % 3) - 1; // -1=Left, 0=Center, 1=Right
        s_props[i].x = lane * 4.2f;
        s_props[i].type = (i % 2 == 0) ? 0 : 1; // Alternate Dirt Ramps and Crush Cars
        s_props[i].width = 2.6f;
        s_props[i].length = 6.5f;
        s_props[i].height = (s_props[i].type == 0) ? 1.85f : 0.95f;
        s_props[i].crushed = 0;
    }
}

// Trigger Loading Screen transition
static void begin_loading_to(GameState target) {
    s_next_state = target;
    s_load_timer = 45; // 0.75 sec authentic 2011 loading screen bar
    s_state = STATE_LOADING;
}

// 3D Perspective Projection Helper
static int project_vertex(float wx, float wy, float wz,
                          float cam_x, float cam_y, float cam_z, float cam_pitch,
                          float* out_sx, float* out_sy, float* out_depth) {
    float dx = wx - cam_x;
    float dy = wy - cam_y;
    float dz = wz - cam_z;

    // Apply slight camera pitch
    float cy = dy * cosf(cam_pitch) - dz * sinf(cam_pitch);
    float cz = dy * sinf(cam_pitch) + dz * cosf(cam_pitch);

    if (cz < 1.2f) return 0; // Behind near clip plane

    float fov_scale = 220.0f;
    *out_sx = (TOP_W * 0.5f) + (dx * fov_scale) / cz;
    *out_sy = (TOP_H * 0.48f) - (cy * fov_scale) / cz;
    *out_depth = cz;
    return 1;
}

// Render a 3D Monster Truck Mesh at arbitrary world pose
static void render_3d_truck(const MonsterTruck* mt, float cam_x, float cam_y, float cam_z, float cam_pitch, float scale_mul) {
    TruckPreset* preset = &s_trucks[mt->truck_id];
    u32 palette[5] = {
        preset->body_col,
        preset->glass_col,
        preset->frame_col,
        preset->tire_col,
        preset->rim_col
    };

    float ch = cosf(mt->heading), sh = sinf(mt->heading);
    float cp = cosf(mt->pitch),   sp = sinf(mt->pitch);
    float cr = cosf(mt->roll),    sr = sinf(mt->roll);

    // Draw Ground Shadow under truck
    float sh_sx, sh_sy, sh_d;
    if (project_vertex(mt->x, 0.02f, mt->z, cam_x, cam_y, cam_z, cam_pitch, &sh_sx, &sh_sy, &sh_d)) {
        float rad_x = (340.0f * scale_mul) / sh_d;
        float rad_y = (140.0f * scale_mul) / sh_d;
        C2D_DrawEllipseSolid(sh_sx - rad_x, sh_sy - rad_y, 0.0f, rad_x * 2.0f, rad_y * 2.0f, C2D_Color32(10, 10, 14, 150));
    }

    // Transform & Project all vertices
    float sx[MAX_VERTS], sy[MAX_VERTS], sz[MAX_VERTS];
    int valid[MAX_VERTS];

    for (int i = 0; i < s_vert_count; i++) {
        Vec3 v = s_mesh_verts[i];
        v.x *= scale_mul;
        v.y *= scale_mul;
        v.z *= scale_mul;

        // Suspension bounce applies to upper body (vertices with y > 0.05)
        if (s_mesh_verts[i].y > 0.05f) {
            v.y += mt->susp_offset;
        }

        // Local Roll (Z-axis) & Pitch (X-axis)
        float rx = v.x * cr - v.y * sr;
        float ry = v.x * sr + v.y * cr;
        float rz = v.z;

        float py = ry * cp - rz * sp;
        float pz = ry * sp + rz * cp;

        // World Heading (Y-axis)
        float wx = mt->x + (rx * ch + pz * sh);
        float wy = mt->y + py + 0.65f * scale_mul;
        float wz = mt->z + (-rx * sh + pz * ch);

        valid[i] = project_vertex(wx, wy, wz, cam_x, cam_y, cam_z, cam_pitch, &sx[i], &sy[i], &sz[i]);
    }

    // Painter's Algorithm depth sort on faces
    int order[MAX_FACES];
    int valid_faces = 0;
    for (int i = 0; i < s_face_count; i++) {
        FaceQuad* fq = &s_mesh_faces[i];
        if (!valid[fq->v[0]] || !valid[fq->v[1]] || !valid[fq->v[2]] || !valid[fq->v[3]]) continue;
        fq->avg_z = (sz[fq->v[0]] + sz[fq->v[1]] + sz[fq->v[2]] + sz[fq->v[3]]) * 0.25f;
        order[valid_faces++] = i;
    }

    // Insertion sort from farthest to nearest
    for (int i = 1; i < valid_faces; i++) {
        int key = order[i];
        float key_z = s_mesh_faces[key].avg_z;
        int j = i - 1;
        while (j >= 0 && s_mesh_faces[order[j]].avg_z < key_z) {
            order[j + 1] = order[j];
            j--;
        }
        order[j + 1] = key;
    }

    for (int idx = 0; idx < valid_faces; idx++) {
        FaceQuad* fq = &s_mesh_faces[order[idx]];
        u32 col = palette[fq->group % 5];
        int v0 = fq->v[0], v1 = fq->v[1], v2 = fq->v[2], v3 = fq->v[3];

        C2D_DrawTriangle(sx[v0], sy[v0], col, sx[v1], sy[v1], col, sx[v2], sy[v2], col, 0.0f);
        if (v3 != v2) {
            C2D_DrawTriangle(sx[v0], sy[v0], col, sx[v2], sy[v2], col, sx[v3], sy[v3], col, 0.0f);
        }
    }
}

// Render 3D Stadium Track, Ramps, Barriers, and Crush Cars
static void render_3d_track_world(float cam_x, float cam_y, float cam_z, float cam_pitch) {
    TrackInfo* trk = &s_tracks[s_selected_track];

    // Sky & Stadium Horizon
    C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H * 0.48f, trk->sky_top);
    C2D_DrawRectSolid(0, TOP_H * 0.32f, 0.0f, TOP_W, TOP_H * 0.16f, trk->sky_horizon);

    // Stadium Lights in background
    for (int lx = 40; lx < TOP_W; lx += 95) {
        C2D_DrawCircleSolid(lx, 36.0f, 0.0f, 10.0f, C2D_Color32(255, 250, 200, 220));
        C2D_DrawCircleSolid(lx, 36.0f, 0.0f, 5.0f, C2D_Color32(255, 255, 255, 255));
    }

    // Ground Base
    C2D_DrawRectSolid(0, TOP_H * 0.48f, 0.0f, TOP_W, TOP_H * 0.52f, trk->ground_primary);

    // Draw Track Segments & Side Barriers (from far to near)
    int base_seg = (int)(cam_z / 6.0f);
    for (int s = base_seg + 22; s >= base_seg + 1; s--) {
        float z0 = s * 6.0f;
        float z1 = (s + 1) * 6.0f;
        float road_w = 8.5f;

        float sx0L, sy0L, d0L, sx0R, sy0R, d0R;
        float sx1L, sy1L, d1L, sx1R, sy1R, d1R;

        if (project_vertex(-road_w, 0.0f, z0, cam_x, cam_y, cam_z, cam_pitch, &sx0L, &sy0L, &d0L) &&
            project_vertex( road_w, 0.0f, z0, cam_x, cam_y, cam_z, cam_pitch, &sx0R, &sy0R, &d0R) &&
            project_vertex(-road_w, 0.0f, z1, cam_x, cam_y, cam_z, cam_pitch, &sx1L, &sy1L, &d1L) &&
            project_vertex( road_w, 0.0f, z1, cam_x, cam_y, cam_z, cam_pitch, &sx1R, &sy1R, &d1R)) {

            u32 dirt_col = (s % 2 == 0) ? trk->ground_primary : trk->ground_secondary;
            C2D_DrawTriangle(sx0L, sy0L, dirt_col, sx0R, sy0R, dirt_col, sx1R, sy1R, dirt_col, 0.0f);
            C2D_DrawTriangle(sx0L, sy0L, dirt_col, sx1R, sy1R, dirt_col, sx1L, sy1L, dirt_col, 0.0f);

            // Alternating Stadium Wall Barriers
            u32 wall_col = (s % 2 == 0) ? trk->barrier_col : C2D_Color32(240, 240, 245, 255);
            float bh = 180.0f / d0L;
            C2D_DrawRectSolid(sx0L - 6.0f, sy0L - bh, 0.0f, 6.0f, bh, wall_col);
            C2D_DrawRectSolid(sx0R, sy0R - bh, 0.0f, 6.0f, bh, wall_col);
        }
    }

    // Render Ramps and Crushable Cars
    for (int i = MAX_PROPS - 1; i >= 0; i--) {
        WorldProp* p = &s_props[i];
        float rel_z = p->z - cam_z;
        if (rel_z < 2.0f || rel_z > 130.0f) continue;

        float sxL, syL, dL, sxR, syR, dR, sxTL, syTL, dTL, sxTR, syTR, dTR;
        float h = p->crushed ? (p->height * 0.35f) : p->height;

        if (project_vertex(p->x - p->width * 0.5f, 0.0f, p->z, cam_x, cam_y, cam_z, cam_pitch, &sxL, &syL, &dL) &&
            project_vertex(p->x + p->width * 0.5f, 0.0f, p->z, cam_x, cam_y, cam_z, cam_pitch, &sxR, &syR, &dR) &&
            project_vertex(p->x - p->width * 0.5f, h, p->z + p->length * 0.5f, cam_x, cam_y, cam_z, cam_pitch, &sxTL, &syTL, &dTL) &&
            project_vertex(p->x + p->width * 0.5f, h, p->z + p->length * 0.5f, cam_x, cam_y, cam_z, cam_pitch, &sxTR, &syTR, &dTR)) {

            u32 pcol;
            if (p->type == 0) {
                // Yellow/Orange Launch Ramp with hazard stripes
                pcol = C2D_Color32(235, 145, 20, 255);
            } else {
                // Crushable Junk Sedan (Blue/Teal or crushed grey)
                pcol = p->crushed ? C2D_Color32(90, 95, 105, 255) : C2D_Color32(45, 150, 210, 255);
            }

            C2D_DrawTriangle(sxL, syL, pcol, sxR, syR, pcol, sxTR, syTR, pcol, 0.0f);
            C2D_DrawTriangle(sxL, syL, pcol, sxTR, syTR, pcol, sxTL, syTL, pcol, 0.0f);
        }
    }
}

// Helper to draw a stylized 2011 Bottom-Screen Touch Button
static void draw_touch_button(int x, int y, int w, int h, u32 fill_col, u32 border_col, int selected) {
    u32 outer = selected ? C2D_Color32(255, 220, 30, 255) : border_col;
    C2D_DrawRectSolid(x, y, 0.0f, w, h, outer);
    C2D_DrawRectSolid(x + 3, y + 3, 0.0f, w - 6, h - 6, fill_col);
    // Glossy 2011 top highlight bar
    C2D_DrawRectSolid(x + 3, y + 3, 0.0f, w - 6, (h - 6) / 3, C2D_Color32(255, 255, 255, 38));
}

static int touch_inside(touchPosition tp, int x, int y, int w, int h) {
    return (tp.px >= x && tp.px <= (x + w) && tp.py >= y && tp.py <= (y + h));
}


static C2D_TextBuf s_text_buf;

static void draw_label(float x, float y, float scale, u32 color, const char* str) {
    C2D_Text text;
    C2D_TextParse(&text, s_text_buf, str);
    C2D_TextOptimize(&text);
    C2D_DrawText(&text, C2D_WithColor, x, y, 0.0f, scale, scale, color);
}

int main(int argc, char* argv[]) {
    gfxInitDefault();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    s_text_buf = C2D_TextBufNew(4096);

    C3D_RenderTarget* topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget* botTarget = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    load_truck_obj("romfs:/monster_truck.obj");
    init_game_audio();

    float preview_rot = 0.0f;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();
        touchPosition touch;
        hidTouchRead(&touch);

        if (kDown & KEY_START) {
            if (s_state == STATE_GAMEPLAY) {
                begin_loading_to(STATE_HOME_MENU);
            } else if (s_state == STATE_HOME_MENU) {
                break; // Exit to Homebrew Launcher from main title
            } else {
                s_state = STATE_HOME_MENU;
            }
        }

        // Toggle audio mute based on options
        if (s_ndsp_ready) {
            float vol = s_opt_music_on ? 1.0f : 0.0f;
            float mix[12] = {0};
            mix[0] = vol;
            mix[1] = vol;
            ndspChnSetMix(0, mix);
        }

        preview_rot += 0.03f;

        // ================= STATE MACHINE & LOGIC =================
        if (s_state == STATE_SPLASH) {
            s_splash_timer++;
            if (s_splash_timer > 90 || (kDown & (KEY_A | KEY_TOUCH))) {
                s_state = STATE_HOME_MENU;
                s_menu_cursor = 0;
            }
        }
        else if (s_state == STATE_LOADING) {
            s_load_timer--;
            if (s_load_timer <= 0) {
                if (s_next_state == STATE_GAMEPLAY) {
                    init_race_session();
                }
                s_state = s_next_state;
            }
        }
        else if (s_state == STATE_HOME_MENU) {
            if (kDown & KEY_DUP)   s_menu_cursor = (s_menu_cursor + 4) % 5;
            if (kDown & KEY_DDOWN) s_menu_cursor = (s_menu_cursor + 1) % 5;

            int trigger = (kDown & KEY_A) ? 1 : 0;
            if (kDown & KEY_TOUCH) {
                for (int b = 0; b < 5; b++) {
                    if (touch_inside(touch, 30, 22 + b * 40, 260, 34)) {
                        s_menu_cursor = b;
                        trigger = 1;
                    }
                }
            }

            if (trigger) {
                if (s_menu_cursor == 0) {
                    s_mode = MODE_CHAMPIONSHIP_RACE;
                    s_state = STATE_GARAGE_SELECT;
                } else if (s_menu_cursor == 1) {
                    s_mode = MODE_FREESTYLE_SHOW;
                    s_state = STATE_GARAGE_SELECT;
                } else if (s_menu_cursor == 2) {
                    s_state = STATE_GARAGE_SELECT;
                } else if (s_menu_cursor == 3) {
                    s_state = STATE_OPTIONS;
                } else if (s_menu_cursor == 4) {
                    s_state = STATE_CONTROLS_HELP;
                }
            }
        }
        else if (s_state == STATE_GARAGE_SELECT) {
            if (kDown & KEY_DLEFT)  s_selected_truck = (s_selected_truck + 2) % 3;
            if (kDown & KEY_DRIGHT) s_selected_truck = (s_selected_truck + 1) % 3;
            if (kDown & KEY_B)      s_state = STATE_HOME_MENU;
            if (kDown & KEY_A)      s_state = STATE_TRACK_SELECT;

            if (kDown & KEY_TOUCH) {
                if (touch_inside(touch, 20, 70, 75, 50))  s_selected_truck = (s_selected_truck + 2) % 3;
                if (touch_inside(touch, 225, 70, 75, 50)) s_selected_truck = (s_selected_truck + 1) % 3;
                if (touch_inside(touch, 60, 150, 200, 42)) s_state = STATE_TRACK_SELECT;
                if (touch_inside(touch, 10, 200, 90, 30))  s_state = STATE_HOME_MENU;
            }
        }
        else if (s_state == STATE_TRACK_SELECT) {
            if (kDown & KEY_DLEFT)  s_selected_track = (s_selected_track + 2) % 3;
            if (kDown & KEY_DRIGHT) s_selected_track = (s_selected_track + 1) % 3;
            if (kDown & KEY_B)      s_state = STATE_GARAGE_SELECT;
            if (kDown & KEY_A)      begin_loading_to(STATE_GAMEPLAY);

            if (kDown & KEY_TOUCH) {
                for (int t = 0; t < 3; t++) {
                    if (touch_inside(touch, 25, 30 + t * 50, 270, 42)) {
                        s_selected_track = t;
                    }
                }
                if (touch_inside(touch, 80, 188, 160, 40)) begin_loading_to(STATE_GAMEPLAY);
                if (touch_inside(touch, 10, 192, 60, 34))  s_state = STATE_GARAGE_SELECT;
            }
        }
        else if (s_state == STATE_OPTIONS) {
            if (kDown & KEY_DUP)   s_menu_cursor = (s_menu_cursor + 3) % 4;
            if (kDown & KEY_DDOWN) s_menu_cursor = (s_menu_cursor + 1) % 4;
            if (kDown & KEY_B)     s_state = STATE_HOME_MENU;

            int toggle = (kDown & (KEY_A | KEY_DLEFT | KEY_DRIGHT)) ? 1 : 0;
            if (kDown & KEY_TOUCH) {
                for (int r = 0; r < 4; r++) {
                    if (touch_inside(touch, 30, 30 + r * 42, 260, 34)) {
                        s_menu_cursor = r;
                        toggle = 1;
                    }
                }
                if (touch_inside(touch, 100, 200, 120, 32)) s_state = STATE_HOME_MENU;
            }
            if (toggle) {
                if (s_menu_cursor == 0) s_opt_music_on = !s_opt_music_on;
                if (s_menu_cursor == 1) s_opt_sfx_on = !s_opt_sfx_on;
                if (s_menu_cursor == 2) s_opt_camera_dist = (s_opt_camera_dist + 1) % 3;
                if (s_menu_cursor == 3) s_opt_difficulty = (s_opt_difficulty + 1) % 3;
            }
        }
        else if (s_state == STATE_CONTROLS_HELP) {
            if (kDown & (KEY_A | KEY_B | KEY_TOUCH)) {
                s_state = STATE_HOME_MENU;
            }
        }
        else if (s_state == STATE_GAMEPLAY) {
            TruckPreset* tp = &s_trucks[s_player.truck_id];
            TrackInfo* trk = &s_tracks[s_selected_track];

            circlePosition cpos;
            hidCircleRead(&cpos);
            float steer = (float)cpos.dx / 155.0f;
            if (kHeld & KEY_DLEFT)  steer = -1.0f;
            if (kHeld & KEY_DRIGHT) steer =  1.0f;

            // Touch steering wheel / pedals on bottom screen
            int touch_gas = 0, touch_nitro = 0, touch_wheelie = 0;
            if (kHeld & KEY_TOUCH) {
                if (touch_inside(touch, 210, 130, 95, 50)) touch_gas = 1;
                if (touch_inside(touch, 210, 65, 95, 55))  touch_nitro = 1;
                if (touch_inside(touch, 15, 130, 95, 50))  touch_wheelie = 1;
                if (touch_inside(touch, 115, 195, 90, 36)) begin_loading_to(STATE_HOME_MENU);
            }

            // Throttle & Braking (A = Gas, B = Brake/Reverse, X or R = Nitro Boost, Y or L = Wheelie)
            if ((kHeld & KEY_A) || touch_gas) {
                s_player.speed += tp->accel;
            } else if (kHeld & KEY_B) {
                s_player.speed -= tp->accel * 1.3f;
            } else {
                s_player.speed *= 0.97f;
            }

            // Nitro Boost (R or X)
            float max_spd = tp->top_speed;
            if (((kHeld & (KEY_R | KEY_X)) || touch_nitro) && s_player.nitro > 1.0f) {
                s_player.nitro -= 0.45f;
                max_spd *= 1.38f;
                s_player.speed += tp->accel * 0.85f;
                spawn_world_particles(s_player.x, s_player.y + 0.5f, s_player.z - 1.4f, C2D_Color32(255, 140, 20, 255), 3);
            } else if (s_player.nitro < 100.0f) {
                s_player.nitro += 0.12f;
            }

            if (s_player.speed > max_spd) s_player.speed = max_spd;
            if (s_player.speed < -0.6f)   s_player.speed = -0.6f;

            // Steering & Body Roll
            if (fabsf(s_player.speed) > 0.05f) {
                s_player.x += steer * 0.24f * (0.5f + s_player.speed / max_spd);
                s_player.heading = steer * 0.26f;
                s_player.roll = -steer * 0.18f;
            } else {
                s_player.heading *= 0.85f;
                s_player.roll *= 0.85f;
            }

            // Stadium Wall Boundaries
            if (s_player.x < -6.8f) { s_player.x = -6.8f; s_player.speed *= 0.9f; }
            if (s_player.x >  6.8f) { s_player.x =  6.8f; s_player.speed *= 0.9f; }

            // Move Forward
            s_player.z += s_player.speed;

            // Mud Rooster Tail Particles when driving fast on ground
            if (!s_player.airborne && s_player.speed > 0.5f && (rand() % 2 == 0)) {
                spawn_world_particles(s_player.x - 0.85f, 0.1f, s_player.z - 1.0f, trk->ground_secondary, 1);
                spawn_world_particles(s_player.x + 0.85f, 0.1f, s_player.z - 1.0f, trk->ground_secondary, 1);
            }

            // Wheelie Pull / Mid-Air Backflip Control (L / Y / CirclePad Up-Down)
            float pitch_input = -(float)cpos.dy / 155.0f;
            if ((kHeld & (KEY_L | KEY_Y)) || touch_wheelie) pitch_input = -1.0f;
            if (kHeld & KEY_DUP)   pitch_input =  1.0f;
            if (kHeld & KEY_DDOWN) pitch_input = -1.0f;

            if (s_player.airborne) {
                s_player.air_time += 1.0f / 60.0f;
                s_player.pitch += pitch_input * 0.08f;
                s_player.vy -= 0.022f; // Gravity
                s_player.y += s_player.vy;

                // Detect full 360 Backflip / Frontflip in mid-air!
                if (fabsf(s_player.pitch) >= 6.0f) {
                    s_player.pitch = 0.0f;
                    s_stunt_score += 500 * s_combo_mult;
                    s_combo_mult++;
                    s_combo_timer = 150;
                    s_last_stunt_name = "MEGA MONSTER BACKFLIP! +500";
                    spawn_world_particles(s_player.x, s_player.y, s_player.z, C2D_Color32(255, 220, 30, 255), 18);
                }

                // Land back on dirt
                if (s_player.y <= 0.0f) {
                    s_player.y = 0.0f;
                    s_player.vy = 0.0f;
                    s_player.airborne = 0;
                    s_player.susp_vel = -0.18f; // Heavy suspension compression on landing
                    if (s_player.air_time > 0.45f) {
                        int air_pts = (int)(s_player.air_time * 250.0f) * s_combo_mult;
                        s_stunt_score += air_pts;
                        s_combo_timer = 120;
                        s_last_stunt_name = "BIG AIR SLAM LANDING!";
                    }
                    s_player.air_time = 0.0f;
                    s_player.pitch *= 0.25f;
                    spawn_world_particles(s_player.x, 0.1f, s_player.z, trk->ground_secondary, 12);
                }
            } else {
                // On ground: Wheelie stand!
                if (pitch_input < -0.4f && s_player.speed > 0.4f) {
                    s_player.pitch = -0.42f;
                    if (((int)(s_race_timer * 60.0f)) % 30 == 0) {
                        s_stunt_score += 50 * s_combo_mult;
                        s_last_stunt_name = "MONSTER WHEELIE! +50";
                    }
                } else {
                    s_player.pitch *= 0.85f;
                }
            }

            // 4-Link Suspension Spring Physics
            float spring_force = -s_player.susp_offset * tp->suspension_stiffness;
            s_player.susp_vel = (s_player.susp_vel + spring_force) * 0.86f;
            s_player.susp_offset += s_player.susp_vel;

            // Check Collisions with Ramps & Crushable Cars
            for (int i = 0; i < MAX_PROPS; i++) {
                WorldProp* p = &s_props[i];
                if (fabsf(s_player.z - p->z) < (p->length * 0.55f) &&
                    fabsf(s_player.x - p->x) < (p->width * 0.72f) &&
                    s_player.y < p->height) {

                    if (p->type == 0 && !s_player.airborne && s_player.speed > 0.35f) {
                        // Launch off dirt ramp!
                        s_player.airborne = 1;
                        s_player.vy = 0.30f + s_player.speed * 0.16f;
                        s_player.pitch = -0.32f;
                        s_last_stunt_name = "SKY LAUNCH RAMP!";
                        spawn_world_particles(s_player.x, 0.4f, s_player.z, C2D_Color32(255, 190, 40, 255), 10);
                    } else if (p->type == 1 && !p->crushed) {
                        // Crush Junk Cars!
                        p->crushed = 1;
                        s_player.susp_vel = 0.14f;
                        s_stunt_score += 200 * s_combo_mult;
                        s_combo_mult++;
                        s_combo_timer = 130;
                        s_last_stunt_name = "CAR CRUSHER MAYHEM! +200";
                        spawn_world_particles(p->x, 0.8f, p->z, C2D_Color32(255, 210, 50, 255), 16);
                    }
                }
            }

            // Combo Timer Decay
            if (s_combo_timer > 0) {
                s_combo_timer--;
                if (s_combo_timer == 0) s_combo_mult = 1;
            }

            // Update AI Monster Trucks
            s_player_rank = 1;
            for (int i = 0; i < 2; i++) {
                float ai_spd = s_trucks[s_ai[i].truck_id].top_speed * (0.76f + 0.07f * s_opt_difficulty + 0.04f * i);
                s_ai[i].z += ai_spd;
                s_ai[i].x += sinf(s_ai[i].z * 0.03f + i * 2.0f) * 0.06f;
                s_ai[i].susp_offset = sinf(s_ai[i].z * 0.3f) * 0.06f;

                if (s_ai[i].z >= trk->length) {
                    s_ai[i].z -= trk->length;
                    s_ai[i].lap++;
                }

                float player_total_d = (s_player.lap - 1) * trk->length + s_player.z;
                float ai_total_d     = (s_ai[i].lap - 1) * trk->length + s_ai[i].z;
                if (ai_total_d > player_total_d) s_player_rank++;
            }

            // Lap & Session Progression
            s_race_timer += 1.0f / 60.0f;
            if (s_mode == MODE_FREESTYLE_SHOW) {
                s_show_timer -= 1.0f / 60.0f;
                if (s_show_timer <= 0.0f) {
                    s_state = STATE_RESULTS;
                }
            }

            if (s_player.z >= trk->length) {
                s_player.z -= trk->length;
                s_player.lap++;
                // Reset crushable cars each lap for continuous mayhem
                for (int i = 0; i < MAX_PROPS; i++) s_props[i].crushed = 0;

                if (s_mode == MODE_CHAMPIONSHIP_RACE && s_player.lap > 3) {
                    s_state = STATE_RESULTS;
                }
            }

            // Update 3D Particles
            for (int i = 0; i < MAX_PARTICLES; i++) {
                if (s_particles[i].life > 0) {
                    s_particles[i].x += s_particles[i].vx;
                    s_particles[i].y += s_particles[i].vy;
                    s_particles[i].z += s_particles[i].vz;
                    s_particles[i].vy -= 0.01f;
                    s_particles[i].life--;
                }
            }
        }
        else if (s_state == STATE_RESULTS) {
            if (kDown & (KEY_A | KEY_START | KEY_TOUCH)) {
                begin_loading_to(STATE_HOME_MENU);
            }
        }

        // ================= DUAL-SCREEN 3DS RENDERING =================
        C2D_TextBufClear(s_text_buf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        // ----------------- TOP SCREEN (400x240 3D VIEWPORT) -----------------
        C2D_TargetClear(topTarget, C2D_Color32(15, 15, 22, 255));
        C2D_SceneBegin(topTarget);

        if (s_state == STATE_SPLASH) {
            // 2011 Prism Ink & Monster Truck Mayhem Splash Screen
            C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H, C2D_Color32(18, 16, 28, 255));
            C2D_DrawRectSolid(40, 50, 0.0f, 320, 140, C2D_Color32(210, 35, 25, 255));
            C2D_DrawRectSolid(46, 56, 0.0f, 308, 128, C2D_Color32(25, 25, 35, 255));

            MonsterTruck splash_mt = {0};
            splash_mt.truck_id = 0;
            splash_mt.heading = preview_rot;
            splash_mt.z = 7.5f;
            render_3d_truck(&splash_mt, 0.0f, 1.8f, 0.0f, 0.12f, 1.15f);
            draw_label(72, 18, 0.85f, C2D_Color32(255, 220, 40, 255), "MONSTER TRUCK MAYHEM!");
            draw_label(125, 205, 0.55f, C2D_Color32(255, 255, 255, 255), "PRISM INK 2011 - PRESS A OR TOUCH");

        }
        else if (s_state == STATE_HOME_MENU || s_state == STATE_GARAGE_SELECT ||
                 s_state == STATE_TRACK_SELECT || s_state == STATE_OPTIONS ||
                 s_state == STATE_CONTROLS_HELP) {

            // Live 3D Showroom Turntable on Top Screen!
            TrackInfo* trk = &s_tracks[s_selected_track];
            C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H * 0.55f, trk->sky_top);
            C2D_DrawRectSolid(0, TOP_H * 0.55f, 0.0f, TOP_W, TOP_H * 0.45f, trk->ground_primary);

            // Showroom Turntable Platform
            C2D_DrawEllipseSolid(90, 145, 0.0f, 220, 65, C2D_Color32(45, 48, 58, 255));
            C2D_DrawEllipseSolid(100, 150, 0.0f, 200, 55, C2D_Color32(230, 150, 20, 255));
            C2D_DrawEllipseSolid(108, 154, 0.0f, 184, 47, C2D_Color32(30, 32, 40, 255));

            // 2011 Chrome/Flame Top Header Banner
            C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, 38, C2D_Color32(185, 20, 25, 255));
            C2D_DrawRectSolid(0, 35, 0.0f, TOP_W, 4, C2D_Color32(255, 215, 0, 255));

            // Render Rotating 3D Monster Truck on Showroom Pedestal
            MonsterTruck show_mt = {0};
            show_mt.truck_id = s_selected_truck;
            show_mt.heading = preview_rot;
            show_mt.susp_offset = sinf(preview_rot * 3.0f) * 0.05f;
            show_mt.z = 6.8f;
            render_3d_truck(&show_mt, 0.0f, 1.65f, 0.0f, 0.14f, 1.25f);
            draw_label(78, 8, 0.75f, C2D_Color32(255, 235, 60, 255), "MONSTER TRUCK MAYHEM! 3D");
            char info_line[96];
            snprintf(info_line, sizeof(info_line), "TRUCK: %s  |  ARENA: %s", s_trucks[s_selected_truck].name, s_tracks[s_selected_track].title);
            draw_label(16, 214, 0.48f, C2D_Color32(255, 255, 255, 255), info_line);

        }
        else if (s_state == STATE_LOADING) {
            // Authentic 2011 3DS Loading Screen with Progress Bar & Spinning Tire
            C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H, C2D_Color32(16, 18, 24, 255));
            C2D_DrawRectSolid(50, 85, 0.0f, 300, 70, C2D_Color32(40, 44, 56, 255));
            float pct = (45.0f - s_load_timer) / 45.0f;
            if (pct < 0.0f) pct = 0.0f;
            if (pct > 1.0f) pct = 1.0f;
            C2D_DrawRectSolid(60, 115, 0.0f, 280.0f * pct, 24.0f, C2D_Color32(255, 165, 0, 255));
            draw_label(110, 52, 0.72f, C2D_Color32(255, 220, 40, 255), "LOADING STADIUM...");
            draw_label(95, 165, 0.50f, C2D_Color32(200, 210, 230, 255), s_tracks[s_selected_track].subtitle);

        }
        else if (s_state == STATE_GAMEPLAY || s_state == STATE_RESULTS) {
            float cam_dist = 6.8f + s_opt_camera_dist * 1.6f;
            float cam_x = s_player.x * 0.65f;
            float cam_y = 2.45f + s_player.y * 0.45f;
            float cam_z = s_player.z - cam_dist;
            float cam_pitch = 0.12f;

            // 1. Render 3D Stadium, Dirt Track, Walls, Ramps & Crushable Cars
            render_3d_track_world(cam_x, cam_y, cam_z, cam_pitch);

            // 2. Render Opponent Monster Trucks
            for (int i = 0; i < 2; i++) {
                float rel_z = s_ai[i].z - cam_z;
                if (rel_z > 2.0f && rel_z < 120.0f) {
                    render_3d_truck(&s_ai[i], cam_x, cam_y, cam_z, cam_pitch, 1.0f);
                }
            }

            // 3. Render Player Monster Truck
            render_3d_truck(&s_player, cam_x, cam_y, cam_z, cam_pitch, 1.0f);

            // 4. Render 3D Particles (Mud, Sparks, Nitro Flames)
            for (int i = 0; i < MAX_PARTICLES; i++) {
                if (s_particles[i].life > 0) {
                    float px, py, pd;
                    if (project_vertex(s_particles[i].x, s_particles[i].y, s_particles[i].z,
                                       cam_x, cam_y, cam_z, cam_pitch, &px, &py, &pd)) {
                        float sz = 22.0f / pd;
                        if (sz < 2.0f) sz = 2.0f;
                        C2D_DrawRectSolid(px, py, 0.0f, sz, sz, s_particles[i].color);
                    }
                }
            }

            // Top Screen Racing HUD Overlay Bars
            // Speedometer & Nitro Gauge (Top-Right)
            C2D_DrawRectSolid(260, 10, 0.0f, 130, 34, C2D_Color32(15, 15, 22, 200));
            float spd_ratio = fabsf(s_player.speed) / 2.2f;
            if (spd_ratio > 1.0f) spd_ratio = 1.0f;
            C2D_DrawRectSolid(265, 14, 0.0f, 120.0f * spd_ratio, 10, C2D_Color32(50, 230, 90, 255));
            C2D_DrawRectSolid(265, 28, 0.0f, 120.0f * (s_player.nitro / 100.0f), 10, C2D_Color32(40, 190, 255, 255));

            // Position / Lap Badge (Top-Left)
            C2D_DrawRectSolid(10, 10, 0.0f, 95, 34, C2D_Color32(190, 25, 25, 220));
            C2D_DrawRectSolid(10, 42, 0.0f, 95, 3, C2D_Color32(255, 215, 0, 255));
            char hud_left[64];
            if (s_mode == MODE_CHAMPIONSHIP_RACE) {
                snprintf(hud_left, sizeof(hud_left), "POS %d/3 | LAP %d/3", s_player_rank, s_player.lap);
            } else {
                snprintf(hud_left, sizeof(hud_left), "SHOW: %02d SEC", (int)s_show_timer);
            }
            draw_label(14, 18, 0.48f, C2D_Color32(255, 255, 255, 255), hud_left);

            char score_str[64];
            snprintf(score_str, sizeof(score_str), "SCORE: %d (x%d)", s_stunt_score, s_combo_mult);
            draw_label(125, 12, 0.52f, C2D_Color32(255, 230, 50, 255), score_str);
            draw_label(115, 215, 0.50f, C2D_Color32(255, 255, 255, 255), s_last_stunt_name);

            if (s_state == STATE_RESULTS) {
                C2D_DrawRectSolid(60, 60, 0.0f, 280, 120, C2D_Color32(15, 18, 28, 235));
                C2D_DrawRectSolid(60, 60, 0.0f, 280, 5, C2D_Color32(255, 215, 0, 255));
                draw_label(115, 75, 0.75f, C2D_Color32(255, 220, 40, 255), "EVENT FINISHED!");
                char res_line[64];
                snprintf(res_line, sizeof(res_line), "FINAL RANK: #%d  |  STUNT PTS: %d", s_player_rank, s_stunt_score);
                draw_label(78, 115, 0.52f, C2D_Color32(255, 255, 255, 255), res_line);
                draw_label(95, 148, 0.48f, C2D_Color32(180, 230, 255, 255), "PRESS A OR TAP TO CONTINUE");
            }

        }

        // ----------------- BOTTOM SCREEN (320x240 TOUCH DASHBOARD) -----------------
        C2D_TargetClear(botTarget, C2D_Color32(22, 24, 32, 255));
        C2D_SceneBegin(botTarget);

        // Metallic Bezel Frame
        C2D_DrawRectSolid(0, 0, 0.0f, BOT_W, BOT_H, C2D_Color32(42, 46, 58, 255));
        C2D_DrawRectSolid(6, 6, 0.0f, BOT_W - 12, BOT_H - 12, C2D_Color32(20, 22, 30, 255));

        if (s_state == STATE_HOME_MENU) {
            for (int b = 0; b < 5; b++) {
                u32 col = (b == 0) ? C2D_Color32(195, 35, 25, 255) :
                          (b == 1) ? C2D_Color32(215, 115, 15, 255) :
                                     C2D_Color32(45, 55, 78, 255);
                draw_touch_button(30, 22 + b * 40, 260, 34, col, C2D_Color32(110, 120, 145, 255), (s_menu_cursor == b));
            }
            draw_label(62, 30,  0.55f, C2D_Color32(255, 255, 255, 255), "1. CHAMPIONSHIP RACING");
            draw_label(62, 70,  0.55f, C2D_Color32(255, 255, 255, 255), "2. FREESTYLE STUNT SHOW");
            draw_label(62, 110, 0.55f, C2D_Color32(255, 255, 255, 255), "3. MONSTER GARAGE");
            draw_label(62, 150, 0.55f, C2D_Color32(255, 255, 255, 255), "4. GAME OPTIONS");
            draw_label(62, 190, 0.55f, C2D_Color32(255, 255, 255, 255), "5. CONTROLS & MANUAL");

        }
        else if (s_state == STATE_GARAGE_SELECT) {
            TruckPreset* tp = &s_trucks[s_selected_truck];
            // Left / Right Truck Selector Arrows
            draw_touch_button(20, 70, 75, 50, C2D_Color32(55, 65, 90, 255), C2D_Color32(140, 150, 175, 255), 0);
            draw_touch_button(225, 70, 75, 50, C2D_Color32(55, 65, 90, 255), C2D_Color32(140, 150, 175, 255), 0);

            // Truck Color Swatch & Stat Bars in Center
            C2D_DrawRectSolid(105, 35, 0.0f, 110, 95, C2D_Color32(32, 36, 48, 255));
            C2D_DrawRectSolid(115, 45, 0.0f, 90, 20, tp->body_col);
            C2D_DrawRectSolid(115, 75, 0.0f, (tp->top_speed / 2.0f) * 90.0f, 10, C2D_Color32(50, 220, 100, 255));
            C2D_DrawRectSolid(115, 95, 0.0f, (tp->accel / 0.06f) * 90.0f, 10, C2D_Color32(255, 180, 30, 255));

            // Select & Back Buttons
            draw_touch_button(60, 150, 200, 42, C2D_Color32(200, 35, 25, 255), C2D_Color32(255, 215, 0, 255), 1);
            draw_touch_button(10, 200, 90, 30, C2D_Color32(60, 65, 80, 255), C2D_Color32(120, 130, 150, 255), 0);
            draw_label(85, 12, 0.60f, C2D_Color32(255, 220, 40, 255), tp->name);
            draw_label(36, 86, 0.55f, C2D_Color32(255, 255, 255, 255), "< PREV");
            draw_label(238, 86, 0.55f, C2D_Color32(255, 255, 255, 255), "NEXT >");
            draw_label(92, 162, 0.58f, C2D_Color32(255, 255, 255, 255), "SELECT TRACK ->");
            draw_label(28, 207, 0.48f, C2D_Color32(255, 255, 255, 255), "BACK (B)");

        }
        else if (s_state == STATE_TRACK_SELECT) {
            for (int t = 0; t < 3; t++) {
                draw_touch_button(25, 30 + t * 50, 270, 42, s_tracks[t].ground_primary, C2D_Color32(140, 150, 170, 255), (s_selected_track == t));
            }
            draw_touch_button(80, 188, 160, 40, C2D_Color32(40, 185, 75, 255), C2D_Color32(255, 230, 50, 255), 1);
            draw_touch_button(10, 192, 60, 34, C2D_Color32(60, 65, 80, 255), C2D_Color32(120, 130, 150, 255), 0);
            for (int t = 0; t < 3; t++) {
                draw_label(40, 42 + t * 50, 0.54f, C2D_Color32(255, 255, 255, 255), s_tracks[t].title);
            }
            draw_label(106, 199, 0.60f, C2D_Color32(255, 255, 255, 255), "START EVENT!");
            draw_label(20, 201, 0.46f, C2D_Color32(255, 255, 255, 255), "BACK");

        }
        else if (s_state == STATE_OPTIONS) {
            for (int r = 0; r < 4; r++) {
                draw_touch_button(30, 30 + r * 42, 260, 34, C2D_Color32(45, 55, 78, 255), C2D_Color32(110, 120, 145, 255), (s_menu_cursor == r));
            }
            draw_touch_button(100, 200, 120, 32, C2D_Color32(190, 40, 30, 255), C2D_Color32(255, 215, 0, 255), 0);
            char opt0[48], opt1[48], opt2[48], opt3[48];
            snprintf(opt0, sizeof(opt0), "MUSIC TRACK: %s", s_opt_music_on ? "ON" : "MUTE");
            snprintf(opt1, sizeof(opt1), "ENGINE SFX: %s", s_opt_sfx_on ? "ON" : "MUTE");
            const char* cam_names[3] = {"CLOSE", "STADIUM", "FAR"};
            snprintf(opt2, sizeof(opt2), "3D CAMERA: %s", cam_names[s_opt_camera_dist]);
            const char* diff_names[3] = {"ROOKIE", "PRO", "MAYHEM"};
            snprintf(opt3, sizeof(opt3), "AI DIFFICULTY: %s", diff_names[s_opt_difficulty]);

            draw_label(48, 39,  0.52f, C2D_Color32(255, 255, 255, 255), opt0);
            draw_label(48, 81,  0.52f, C2D_Color32(255, 255, 255, 255), opt1);
            draw_label(48, 123, 0.52f, C2D_Color32(255, 255, 255, 255), opt2);
            draw_label(48, 165, 0.52f, C2D_Color32(255, 255, 255, 255), opt3);
            draw_label(122, 208, 0.50f, C2D_Color32(255, 255, 255, 255), "SAVE & BACK");

        }
        else if (s_state == STATE_CONTROLS_HELP || s_state == STATE_RESULTS) {
            draw_label(35, 18, 0.58f, C2D_Color32(255, 220, 40, 255), "MONSTER TRUCK CONTROLS:");
            draw_label(22, 48, 0.46f, C2D_Color32(255, 255, 255, 255), "- A BUTTON / TOUCH GAS: Accelerate");
            draw_label(22, 70, 0.46f, C2D_Color32(255, 255, 255, 255), "- B BUTTON: Brakes & Reverse");
            draw_label(22, 92, 0.46f, C2D_Color32(255, 255, 255, 255), "- CIRCLE PAD / D-PAD: Steer & Pitch");
            draw_label(22, 114, 0.46f, C2D_Color32(255, 255, 255, 255), "- R OR X BUTTON: Flame Nitro Boost");
            draw_label(22, 136, 0.46f, C2D_Color32(255, 255, 255, 255), "- L OR Y BUTTON: Wheelie / Backflip");
            draw_label(22, 158, 0.46f, C2D_Color32(255, 255, 255, 255), "- CRUSH BLUE CARS & LAUNCH RAMPS!");
            draw_touch_button(70, 188, 180, 38, C2D_Color32(200, 40, 30, 255), C2D_Color32(255, 215, 0, 255), 1);
            draw_label(108, 198, 0.52f, C2D_Color32(255, 255, 255, 255), "MAIN MENU");
        }
        else if (s_state == STATE_GAMEPLAY) {
            // Live Interactive Monster Truck Cockpit & Track Radar on Bottom Screen!
            // 1. Track Progress Radar Bar (Top of Bottom Screen)
            C2D_DrawRectSolid(20, 18, 0.0f, 280, 26, C2D_Color32(35, 40, 52, 255));
            float trk_len = s_tracks[s_selected_track].length;
            for (int i = 0; i < 2; i++) {
                float ai_x = 24.0f + (s_ai[i].z / trk_len) * 272.0f;
                C2D_DrawCircleSolid(ai_x, 31.0f, 0.0f, 5.0f, C2D_Color32(255, 60, 60, 255));
            }
            float pl_x = 24.0f + (s_player.z / trk_len) * 272.0f;
            C2D_DrawCircleSolid(pl_x, 31.0f, 0.0f, 6.5f, C2D_Color32(50, 240, 90, 255));

            // 2. Touch Controls: NITRO Button, GAS Pedal, WHEELIE Pull, MENU Button
            draw_touch_button(210, 65,  95, 55, C2D_Color32(30, 150, 230, 255), C2D_Color32(180, 235, 255, 255), (s_player.nitro > 25.0f));
            draw_touch_button(210, 130, 95, 50, C2D_Color32(40, 185, 70, 255),  C2D_Color32(160, 250, 180, 255), 0);
            draw_touch_button(15,  130, 95, 50, C2D_Color32(220, 115, 20, 255), C2D_Color32(255, 215, 90, 255),  0);
            draw_touch_button(115, 195, 90, 36, C2D_Color32(80, 85, 105, 255),  C2D_Color32(160, 170, 190, 255), 0);

            // 3. Central RPM / Stunt Score Display Box
            C2D_DrawRectSolid(115, 65, 0.0f, 90, 115, C2D_Color32(14, 16, 22, 255));
            float rpm_h = (fabsf(s_player.speed) / 2.0f) * 95.0f;
            if (rpm_h > 95.0f) rpm_h = 95.0f;
            C2D_DrawRectSolid(125, 170 - rpm_h, 0.0f, 22, rpm_h, C2D_Color32(245, 80, 25, 255));
            float nit_h = (s_player.nitro / 100.0f) * 95.0f;
            C2D_DrawRectSolid(170, 170 - nit_h, 0.0f, 22, nit_h, C2D_Color32(40, 195, 255, 255));
            draw_label(228, 84,  0.52f, C2D_Color32(255, 255, 255, 255), "NITRO (R)");
            draw_label(232, 146, 0.52f, C2D_Color32(255, 255, 255, 255), "GAS (A)");
            draw_label(24,  146, 0.48f, C2D_Color32(255, 255, 255, 255), "WHEELIE (L)");
            draw_label(125, 172, 0.42f, C2D_Color32(255, 200, 150, 255), "RPM   NITRO");
            draw_label(136, 205, 0.48f, C2D_Color32(255, 255, 255, 255), "QUIT");

        }

        C3D_FrameEnd(0);
    }

    cleanup_game_audio();
    C2D_TextBufDelete(s_text_buf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
