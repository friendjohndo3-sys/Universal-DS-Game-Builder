# Spooky Knight: 2D Pixel Dungeon (Nintendo 3DS)

A fast-paced retro 2D top-down dungeon crawler featuring the Pumpkin Knight, real-time sword combat, bat AI, and a live dual-screen minimap!

## Controls:
- **Circle Pad / D-Pad**: Move Pumpkin Knight in 8 directions
- **A Button**: Sword slash attack with particle effects
- **START**: Exit to Homebrew launcher

## Dual Screen Features:
- **Top Screen**: Full pixel art dungeon renderer, animated bat enemies, glowing soul gems, and particle engine.
- **Bottom Screen**: Live radar minimap displaying player blip, bat positions, HP bar, and collected soul counter.

## Automated Cloud Build:
Push this folder to any GitHub repository and GitHub Actions will compile `spooky_dungeon.3dsx` automatically under the **Actions** tab!
