#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define SCREEN_TOP_W    400
#define SCREEN_TOP_H    240
#define SCREEN_BOT_W    320
#define SCREEN_BOT_H    240

#define MAP_COLS 25
#define MAP_ROWS 15
#define TILE_SIZE 16

// Map: 1 = Wall, 0 = Floor, 2 = Torch, 3 = Soul Gem
static u8 dungeon_map[MAP_ROWS][MAP_COLS] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
    {1,0,3,0,0,0,1,0,3,0,0,0,0,3,0,1,0,0,3,0,0,0,3,0,1},
    {1,0,0,1,1,0,0,0,1,1,1,0,1,1,0,0,0,1,1,1,0,0,0,0,1},
    {1,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1,0,0,0,0,1},
    {1,0,0,1,0,3,0,0,3,0,1,0,1,0,3,0,0,3,0,1,0,0,0,0,1},
    {1,0,0,0,0,1,1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,1,1,0,0,0,1,1,0,1,1,0,0,0,1,1,1,0,0,0,0,1},
    {1,0,0,0,0,1,0,3,0,1,0,0,0,1,0,3,0,1,0,0,0,0,0,0,1},
    {1,0,3,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,3,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

typedef struct {
    float x, y;
    float vx, vy;
    float dirX, dirY;
    int hp;
    int maxHp;
    int souls;
    int attackTimer;
    int invulnTimer;
    int facing; // 0=Down, 1=Up, 2=Left, 3=Right
} Player;

typedef struct {
    float x, y;
    float vx, vy;
    int active;
    int hp;
    float hoverPhase;
} BatEnemy;

#define MAX_BATS 8
static BatEnemy bats[MAX_BATS];

typedef struct {
    float x, y;
    float vx, vy;
    u32 color;
    int life;
} Particle;

#define MAX_PARTICLES 64
static Particle particles[MAX_PARTICLES];

void spawn_particles(float x, float y, u32 color, int count) {
    for (int i = 0; i < MAX_PARTICLES && count > 0; i++) {
        if (particles[i].life <= 0) {
            particles[i].x = x;
            particles[i].y = y;
            float angle = ((float)rand() / RAND_MAX) * 6.28318f;
            float speed = 1.0f + ((float)rand() / RAND_MAX) * 2.5f;
            particles[i].vx = cosf(angle) * speed;
            particles[i].vy = sinf(angle) * speed;
            particles[i].color = color;
            particles[i].life = 15 + (rand() % 15);
            count--;
        }
    }
}

int is_solid(float x, float y) {
    int tx = (int)(x / TILE_SIZE);
    int ty = (int)(y / TILE_SIZE);
    if (tx < 0 || tx >= MAP_COLS || ty < 0 || ty >= MAP_ROWS) return 1;
    return (dungeon_map[ty][tx] == 1);
}

int main(int argc, char* argv[]) {
    // 1. Initialize 3DS hardware
    gfxInitDefault();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    // Setup Render Targets
    C3D_RenderTarget* topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget* botTarget = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    // 2. Initialize Player
    Player player = {
        .x = 48.0f, .y = 48.0f,
        .vx = 0.0f, .vy = 0.0f,
        .dirX = 0.0f, .dirY = 1.0f,
        .hp = 100, .maxHp = 100,
        .souls = 0,
        .attackTimer = 0,
        .invulnTimer = 0,
        .facing = 0
    };

    // 3. Initialize Enemies
    float bat_spawns[MAX_BATS][2] = {
        {180.0f, 60.0f}, {280.0f, 80.0f}, {320.0f, 160.0f},
        {140.0f, 180.0f}, {220.0f, 120.0f}, {80.0f, 190.0f},
        {300.0f, 40.0f}, {250.0f, 200.0f}
    };
    for (int i = 0; i < MAX_BATS; i++) {
        bats[i].x = bat_spawns[i][0];
        bats[i].y = bat_spawns[i][1];
        bats[i].vx = 0.0f;
        bats[i].vy = 0.0f;
        bats[i].active = 1;
        bats[i].hp = 2;
        bats[i].hoverPhase = (float)i * 0.8f;
    }

    u32 col_wall   = C2D_Color32(35, 30, 50, 255);
    u32 col_wall_top = C2D_Color32(50, 45, 75, 255);
    u32 col_floor  = C2D_Color32(70, 65, 88, 255);
    u32 col_floor_grid = C2D_Color32(60, 55, 76, 255);
    u32 col_gold   = C2D_Color32(255, 215, 30, 255);
    u32 col_bat    = C2D_Color32(140, 70, 180, 255);
    u32 col_pumpkin = C2D_Color32(245, 115, 20, 255);
    u32 col_slash  = C2D_Color32(180, 240, 255, 220);

    // Main Game Loop
    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();

        if (kDown & KEY_START) break;

        // Player Controls (Circle Pad & D-Pad)
        circlePosition cpos;
        hidCircleRead(&cpos);
        float moveX = (float)cpos.dx / 150.0f;
        float moveY = -(float)cpos.dy / 150.0f;

        if (kHeld & KEY_DLEFT)  moveX = -1.5f;
        if (kHeld & KEY_DRIGHT) moveX =  1.5f;
        if (kHeld & KEY_DUP)    moveY = -1.5f;
        if (kHeld & KEY_DDOWN)  moveY =  1.5f;

        if (fabsf(moveX) > 0.1f || fabsf(moveY) > 0.1f) {
            player.dirX = moveX;
            player.dirY = moveY;
            if (fabsf(moveX) > fabsf(moveY)) {
                player.facing = (moveX > 0) ? 3 : 2;
            } else {
                player.facing = (moveY > 0) ? 0 : 1;
            }
        }

        // Horizontal collision
        float newX = player.x + moveX;
        if (!is_solid(newX - 6.0f, player.y - 6.0f) &&
            !is_solid(newX + 6.0f, player.y - 6.0f) &&
            !is_solid(newX - 6.0f, player.y + 6.0f) &&
            !is_solid(newX + 6.0f, player.y + 6.0f)) {
            player.x = newX;
        }

        // Vertical collision
        float newY = player.y + moveY;
        if (!is_solid(player.x - 6.0f, newY - 6.0f) &&
            !is_solid(player.x + 6.0f, newY - 6.0f) &&
            !is_solid(player.x - 6.0f, newY + 6.0f) &&
            !is_solid(player.x + 6.0f, newY + 6.0f)) {
            player.y = newY;
        }

        // Soul Gem Pickups
        int ptx = (int)(player.x / TILE_SIZE);
        int pty = (int)(player.y / TILE_SIZE);
        if (ptx >= 0 && ptx < MAP_COLS && pty >= 0 && pty < MAP_ROWS) {
            if (dungeon_map[pty][ptx] == 3) {
                dungeon_map[pty][ptx] = 0; // collect
                player.souls++;
                spawn_particles(player.x, player.y, col_gold, 12);
            }
        }

        // Attack (A Button)
        if ((kDown & KEY_A) && player.attackTimer <= 0) {
            player.attackTimer = 12; // 12 frames slash animation
            spawn_particles(player.x + player.dirX * 12.0f, player.y + player.dirY * 12.0f, col_slash, 6);
        }
        if (player.attackTimer > 0) player.attackTimer--;
        if (player.invulnTimer > 0) player.invulnTimer--;

        // Update Bats AI
        for (int i = 0; i < MAX_BATS; i++) {
            if (!bats[i].active) continue;

            bats[i].hoverPhase += 0.1f;
            float dx = player.x - bats[i].x;
            float dy = player.y - bats[i].y;
            float dist = sqrtf(dx * dx + dy * dy);

            // Chasing when within range
            if (dist < 120.0f && dist > 2.0f) {
                bats[i].vx += (dx / dist) * 0.15f;
                bats[i].vy += (dy / dist) * 0.15f;
            }
            bats[i].vx *= 0.92f; // Friction
            bats[i].vy *= 0.92f;
            bats[i].x += bats[i].vx;
            bats[i].y += bats[i].vy;

            // Attack Hitbox collision
            if (player.attackTimer > 6) {
                float slashX = player.x + player.dirX * 16.0f;
                float slashY = player.y + player.dirY * 16.0f;
                float hx = bats[i].x - slashX;
                float hy = bats[i].y - slashY;
                if (sqrtf(hx * hx + hy * hy) < 20.0f) {
                    bats[i].hp--;
                    bats[i].vx = player.dirX * 4.0f;
                    bats[i].vy = player.dirY * 4.0f;
                    spawn_particles(bats[i].x, bats[i].y, C2D_Color32(255, 60, 60, 255), 10);
                    if (bats[i].hp <= 0) {
                        bats[i].active = 0;
                        player.souls += 2;
                        spawn_particles(bats[i].x, bats[i].y, col_gold, 16);
                    }
                }
            }

            // Hurt player on touch
            if (dist < 12.0f && player.invulnTimer <= 0) {
                player.hp -= 10;
                player.invulnTimer = 30; // 0.5s invulnerability
                spawn_particles(player.x, player.y, C2D_Color32(255, 40, 40, 255), 8);
                if (player.hp < 0) player.hp = 0;
            }
        }

        // Update Particles
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (particles[i].life > 0) {
                particles[i].x += particles[i].vx;
                particles[i].y += particles[i].vy;
                particles[i].life--;
            }
        }

        // ================= RENDERING =================
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        // --- TOP SCREEN: Pixel Dungeon Gameplay ---
        C2D_TargetClear(topTarget, C2D_Color32(20, 15, 25, 255));
        C2D_SceneBegin(topTarget);

        // 1. Draw Tilemap
        for (int r = 0; r < MAP_ROWS; r++) {
            for (int c = 0; c < MAP_COLS; c++) {
                float tx = c * TILE_SIZE;
                float ty = r * TILE_SIZE;
                if (dungeon_map[r][c] == 1) {
                    // Wall
                    C2D_DrawRectSolid(tx, ty, 0.0f, TILE_SIZE, TILE_SIZE, col_wall);
                    C2D_DrawRectSolid(tx, ty, 0.0f, TILE_SIZE, 3.0f, col_wall_top);
                } else {
                    // Floor
                    C2D_DrawRectSolid(tx, ty, 0.0f, TILE_SIZE, TILE_SIZE, col_floor);
                    C2D_DrawRectSolid(tx, ty, 0.0f, 1.0f, TILE_SIZE, col_floor_grid);
                    C2D_DrawRectSolid(tx, ty, 0.0f, TILE_SIZE, 1.0f, col_floor_grid);

                    // Collectible Soul Gem
                    if (dungeon_map[r][c] == 3) {
                        float pulse = sinf(osGetTime() / 150.0f + c) * 1.5f;
                        C2D_DrawCircleSolid(tx + 8.0f, ty + 8.0f, 0.0f, 4.0f + pulse, col_gold);
                        C2D_DrawCircleSolid(tx + 8.0f, ty + 8.0f, 0.0f, 2.0f, C2D_Color32(255, 255, 200, 255));
                    }
                }
            }
        }

        // 2. Draw Enemies (Bats)
        for (int i = 0; i < MAX_BATS; i++) {
            if (!bats[i].active) continue;
            float hoverY = sinf(bats[i].hoverPhase) * 3.0f;
            float bx = bats[i].x;
            float by = bats[i].y + hoverY;

            // Shadow
            C2D_DrawEllipseSolid(bx, bats[i].y + 8.0f, 0.0f, 6.0f, 3.0f, C2D_Color32(10, 10, 15, 120));
            // Wings & Body
            float wing = sinf(bats[i].hoverPhase * 2.5f) * 4.0f;
            C2D_DrawTriangle(bx - 7.0f, by - wing, col_bat, bx, by + 2.0f, col_bat, bx - 1.0f, by - 3.0f, col_bat, 0.0f);
            C2D_DrawTriangle(bx + 7.0f, by - wing, col_bat, bx, by + 2.0f, col_bat, bx + 1.0f, by - 3.0f, col_bat, 0.0f);
            C2D_DrawCircleSolid(bx, by, 0.0f, 3.5f, C2D_Color32(70, 30, 90, 255));
            // Eyes
            C2D_DrawRectSolid(bx - 2.0f, by - 1.0f, 0.0f, 1.0f, 1.0f, C2D_Color32(255, 50, 50, 255));
            C2D_DrawRectSolid(bx + 1.0f, by - 1.0f, 0.0f, 1.0f, 1.0f, C2D_Color32(255, 50, 50, 255));
        }

        // 3. Draw Player (Pumpkin Knight)
        if (player.invulnTimer % 4 < 2) {
            // Shadow
            C2D_DrawEllipseSolid(player.x, player.y + 8.0f, 0.0f, 7.0f, 3.5f, C2D_Color32(10, 10, 15, 140));

            // Cloak
            C2D_DrawRectSolid(player.x - 5.0f, player.y, 0.0f, 10.0f, 8.0f, C2D_Color32(40, 45, 60, 255));

            // Pumpkin Head
            C2D_DrawCircleSolid(player.x, player.y - 3.0f, 0.0f, 6.5f, col_pumpkin);
            // Stem
            C2D_DrawRectSolid(player.x - 1.0f, player.y - 11.0f, 0.0f, 2.0f, 3.0f, C2D_Color32(50, 160, 50, 255));

            // Face Glow
            u32 glow = C2D_Color32(255, 240, 60, 255);
            C2D_DrawRectSolid(player.x - 3.0f, player.y - 4.0f, 0.0f, 2.0f, 2.0f, glow);
            C2D_DrawRectSolid(player.x + 1.0f, player.y - 4.0f, 0.0f, 2.0f, 2.0f, glow);
            C2D_DrawRectSolid(player.x - 1.0f, player.y - 1.0f, 0.0f, 2.0f, 1.0f, glow);

            // Sword Slash Arc
            if (player.attackTimer > 0) {
                float sx = player.x + player.dirX * 14.0f;
                float sy = player.y + player.dirY * 14.0f;
                C2D_DrawCircleSolid(sx, sy, 0.0f, 9.0f, col_slash);
                C2D_DrawCircleSolid(sx, sy, 0.0f, 5.0f, C2D_Color32(255, 255, 255, 255));
            }
        }

        // 4. Draw Particles
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (particles[i].life > 0) {
                C2D_DrawRectSolid(particles[i].x, particles[i].y, 0.0f, 2.0f, 2.0f, particles[i].color);
            }
        }

        // --- BOTTOM SCREEN: HUD, Dungeon Minimap & Stats ---
        C2D_TargetClear(botTarget, C2D_Color32(15, 12, 20, 255));
        C2D_SceneBegin(botTarget);

        // Border
        C2D_DrawRectSolid(6.0f, 6.0f, 0.0f, SCREEN_BOT_W - 12.0f, SCREEN_BOT_H - 12.0f, C2D_Color32(25, 20, 35, 255));
        C2D_DrawRectSolid(8.0f, 8.0f, 0.0f, SCREEN_BOT_W - 16.0f, SCREEN_BOT_H - 16.0f, C2D_Color32(18, 14, 26, 255));

        // HP Bar
        C2D_DrawRectSolid(20.0f, 20.0f, 0.0f, 140.0f, 16.0f, C2D_Color32(40, 15, 20, 255));
        float hpWidth = (player.hp / (float)player.maxHp) * 136.0f;
        if (hpWidth < 0.0f) hpWidth = 0.0f;
        C2D_DrawRectSolid(22.0f, 22.0f, 0.0f, hpWidth, 12.0f, C2D_Color32(230, 45, 55, 255));

        // Soul Gems / Score
        C2D_DrawCircleSolid(200.0f, 28.0f, 0.0f, 6.0f, col_gold);
        for (int s = 0; s < player.souls && s < 10; s++) {
            C2D_DrawCircleSolid(220.0f + s * 9.0f, 28.0f, 0.0f, 3.5f, col_gold);
        }

        // Interactive Minimap (Centered on bottom screen)
        float mapStartX = 35.0f;
        float mapStartY = 60.0f;
        float mTile = 10.0f;
        for (int r = 0; r < MAP_ROWS; r++) {
            for (int c = 0; c < MAP_COLS; c++) {
                float mx = mapStartX + c * mTile;
                float my = mapStartY + r * mTile;
                if (dungeon_map[r][c] == 1) {
                    C2D_DrawRectSolid(mx, my, 0.0f, mTile - 1.0f, mTile - 1.0f, C2D_Color32(60, 55, 80, 255));
                } else {
                    C2D_DrawRectSolid(mx, my, 0.0f, mTile - 1.0f, mTile - 1.0f, C2D_Color32(35, 30, 48, 255));
                    if (dungeon_map[r][c] == 3) {
                        C2D_DrawCircleSolid(mx + mTile / 2.0f, my + mTile / 2.0f, 0.0f, 2.0f, col_gold);
                    }
                }
            }
        }

        // Minimap Player Blip
        float pBlipX = mapStartX + (player.x / TILE_SIZE) * mTile;
        float pBlipY = mapStartY + (player.y / TILE_SIZE) * mTile;
        C2D_DrawCircleSolid(pBlipX, pBlipY, 0.0f, 3.5f, C2D_Color32(50, 220, 90, 255));

        // Minimap Bat Blips
        for (int i = 0; i < MAX_BATS; i++) {
            if (bats[i].active) {
                float bBlipX = mapStartX + (bats[i].x / TILE_SIZE) * mTile;
                float bBlipY = mapStartY + (bats[i].y / TILE_SIZE) * mTile;
                C2D_DrawCircleSolid(bBlipX, bBlipY, 0.0f, 2.5f, C2D_Color32(230, 40, 80, 255));
            }
        }

        C3D_FrameEnd(0);
    }

    // Cleanup
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
