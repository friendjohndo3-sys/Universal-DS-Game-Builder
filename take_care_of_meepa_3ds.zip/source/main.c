#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TOP_W 400
#define TOP_H 240
#define BOT_W 320
#define BOT_H 240

// Locations / Environments
typedef enum {
    LOC_HOUSE_INSIDE = 0,
    LOC_OUTSIDE_PARK = 1,
    LOC_MEEPA_STORE  = 2
} LocationID;

// Interactive Modes
typedef enum {
    ACT_IDLE_CARE = 0,
    ACT_FEEDING   = 1,
    ACT_WARDROBE  = 2,
    ACT_BATH_SCRUB= 3,
    ACT_SLEEPING  = 4,
    ACT_MINIGAME  = 5,
    ACT_SHOPPING  = 6
} ActionMode;

typedef struct { float x, y, z; } Vec3;
typedef struct {
    int v[4];
    float avg_z;
    float shade;
} FaceQuad;

#define MAX_VERTS 128
#define MAX_FACES 128
static Vec3 s_base_verts[MAX_VERTS];
static FaceQuad s_faces[MAX_FACES];
static int s_vert_count = 0;
static int s_face_count = 0;

// Meepa Pet Care Stats & Customization
static float s_stat_hunger  = 80.0f;
static float s_stat_happy   = 85.0f;
static float s_stat_energy  = 90.0f;
static float s_stat_hygiene = 75.0f;
static int   s_meepa_coins  = 120;

// Wardrobe Hats (0=None, 1=Gold Crown, 2=Red Top Hat, 3=Propeller Cap, 4=Pink Bowtie)
static int s_equipped_hat = 0;
static int s_owned_hats[5] = {1, 1, 0, 0, 0};
static const char* s_hat_names[5] = {
    "NONE", "ROYAL CROWN", "RED TOP HAT", "PROPELLER CAP", "PINK BOWTIE"
};
static int s_hat_prices[5] = {0, 0, 50, 75, 40};

// Food Inventory (0=Red Apple, 1=Pink Donut, 2=Pizza Slice, 3=Berry Soda)
static int s_selected_food = 0;
static int s_food_counts[4] = {3, 2, 1, 2};
static const char* s_food_names[4] = {
    "CRISP APPLE", "FROSTED DONUT", "CHEESE PIZZA", "BERRY SODA"
};
static int s_food_prices[4] = {10, 20, 30, 15};
static int s_food_timer = 0;

// Animation & World State
static LocationID s_location = LOC_HOUSE_INSIDE;
static ActionMode s_action   = ACT_IDLE_CARE;
static float s_anim_time = 0.0f;
static float s_meepa_rot = 0.0f;
static float s_meepa_bob = 0.0f;
static float s_arm_wave  = 0.0f;
static int   s_happy_timer = 0;
static const char* s_status_msg = "Meepa loves floating around with you! :3";

// Mini-Game Ball State
static float s_ball_x = 0.0f, s_ball_y = 0.5f, s_ball_z = 2.0f;
static float s_ball_vx = 0.03f, s_ball_vz = 0.07f;
static int   s_rally_score = 0;

// Floating 3D Particles (Hearts, Soap Bubbles, Music Notes)
typedef struct {
    float x, y, z, vy;
    u32 color;
    int life;
} Particle;
#define MAX_PARTICLES 40
static Particle s_particles[MAX_PARTICLES];

// Audio Streaming
static u8* s_audio_buf = NULL;
static u32 s_audio_size = 0;
static ndspWaveBuf s_wave_buf;
static int s_ndsp_ready = 0;
static C2D_TextBuf s_text_buf;

static void draw_label(float x, float y, float scale, u32 col, const char* str) {
    C2D_Text text;
    C2D_TextParse(&text, s_text_buf, str);
    C2D_TextOptimize(&text);
    C2D_DrawText(&text, C2D_WithColor, x, y, 0.0f, scale, scale, col);
}

static void spawn_particles(u32 col, int count) {
    for (int i = 0; i < MAX_PARTICLES && count > 0; i++) {
        if (s_particles[i].life <= 0) {
            s_particles[i].x = ((rand() % 100) - 50) * 0.025f;
            s_particles[i].y = -0.3f + ((rand() % 60) * 0.015f);
            s_particles[i].z = 4.2f;
            s_particles[i].vy = 0.02f + (rand() % 20) * 0.001f;
            s_particles[i].color = col;
            s_particles[i].life = 35 + (rand() % 25);
            count--;
        }
    }
}

// Load exact low-poly Meepa OBJ from RomFS
static void load_meepa_obj(const char* path) {
    s_vert_count = 0;
    s_face_count = 0;
    FILE* f = fopen(path, "r");
    if (!f) return;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "v ", 2) == 0) {
            Vec3 v;
            if (sscanf(line + 2, "%f %f %f", &v.x, &v.y, &v.z) == 3 && s_vert_count < MAX_VERTS) {
                s_base_verts[s_vert_count++] = v;
            }
        } else if (strncmp(line, "f ", 2) == 0) {
            int v1=1, t1=1, n1=1, v2=1, t2=1, n2=1, v3=1, t3=1, n3=1, v4=1, t4=1, n4=1;
            int m = sscanf(line + 2, "%d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d",
                           &v1, &t1, &n1, &v2, &t2, &n2, &v3, &t3, &n3, &v4, &t4, &n4);
            if (m >= 9 && s_face_count < MAX_FACES) {
                FaceQuad fq;
                fq.v[0] = v1 - 1;
                fq.v[1] = v2 - 1;
                fq.v[2] = v3 - 1;
                fq.v[3] = (m == 12) ? (v4 - 1) : (v3 - 1);
                fq.avg_z = 0.0f;
                fq.shade = 1.0f;
                s_faces[s_face_count++] = fq;
            }
        }
    }
    fclose(f);
}

static void init_meepa_audio(void) {
    FILE* f = fopen("romfs:/meepa_theme.raw", "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END);
    s_audio_size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (s_audio_size > 0) {
        s_audio_buf = (u8*)linearAlloc(s_audio_size);
        if (s_audio_buf) {
            fread(s_audio_buf, 1, s_audio_size, f);
            DSP_FlushDataCache(s_audio_buf, s_audio_size);
        }
    }
    fclose(f);

    if (s_audio_buf && R_SUCCEEDED(ndspInit())) {
        s_ndsp_ready = 1;
        ndspSetOutputMode(NDSP_OUTPUT_MONO);
        ndspChnReset(0);
        ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
        ndspChnSetRate(0, 22050.0f);
        ndspChnSetFormat(0, NDSP_FORMAT_MONO_PCM16);
        memset(&s_wave_buf, 0, sizeof(s_wave_buf));
        s_wave_buf.data_vaddr = s_audio_buf;
        s_wave_buf.nsamples = s_audio_size / 2;
        s_wave_buf.looping = true;
        ndspChnWaveBufAdd(0, &s_wave_buf);
    }
}

static int project_pt(float wx, float wy, float wz, float* sx, float* sy, float* depth) {
    if (wz < 1.0f) return 0;
    float fov = 215.0f;
    *sx = (TOP_W * 0.5f) + (wx * fov) / wz;
    *sy = (TOP_H * 0.54f) - (wy * fov) / wz;
    *depth = wz;
    return 1;
}

// Render 3D Environment Room (House Inside, Park Outside, or Meepa Store)
static void render_3d_environment(LocationID loc) {
    if (loc == LOC_HOUSE_INSIDE) {
        // Cozy Living Room Wallpaper & Warm Wooden Floor
        C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, 135, C2D_Color32(245, 222, 195, 255));
        for (int x = 20; x < TOP_W; x += 40) {
            C2D_DrawRectSolid(x, 0, 0.0f, 12, 135, C2D_Color32(235, 205, 175, 255));
        }
        // Sunlit Window
        C2D_DrawRectSolid(285, 25, 0.0f, 75, 65, C2D_Color32(130, 90, 60, 255));
        C2D_DrawRectSolid(291, 31, 0.0f, 63, 53, C2D_Color32(135, 215, 255, 255));
        // Wooden Floorboards & Cozy Rug
        C2D_DrawRectSolid(0, 135, 0.0f, TOP_W, 105, C2D_Color32(165, 110, 68, 255));
        C2D_DrawEllipseSolid(95, 162, 0.0f, 210, 56, C2D_Color32(220, 85, 95, 255));
        C2D_DrawEllipseSolid(110, 168, 0.0f, 180, 44, C2D_Color32(245, 195, 90, 255));
    }
    else if (loc == LOC_OUTSIDE_PARK) {
        // Sunny Blue Sky & Lush Green Park Meadow
        C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, 130, C2D_Color32(95, 190, 255, 255));
        C2D_DrawEllipseSolid(50, 32, 0.0f, 80, 28, C2D_Color32(255, 255, 255, 230));
        C2D_DrawEllipseSolid(260, 42, 0.0f, 95, 30, C2D_Color32(255, 255, 255, 230));
        // Distant Hills & Grass
        C2D_DrawEllipseSolid(-30, 100, 0.0f, 240, 70, C2D_Color32(90, 195, 95, 255));
        C2D_DrawEllipseSolid(190, 95, 0.0f, 250, 75, C2D_Color32(80, 180, 85, 255));
        C2D_DrawRectSolid(0, 130, 0.0f, TOP_W, 110, C2D_Color32(105, 210, 100, 255));
        C2D_DrawEllipseSolid(100, 165, 0.0f, 200, 50, C2D_Color32(230, 205, 145, 255));
    }
    else {
        // Meepa Mart Store (Checkered Floor & Shelves)
        C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, 135, C2D_Color32(215, 235, 250, 255));
        C2D_DrawRectSolid(30, 35, 0.0f, 340, 14, C2D_Color32(230, 85, 65, 255));
        C2D_DrawRectSolid(30, 80, 0.0f, 340, 10, C2D_Color32(180, 140, 95, 255));
        C2D_DrawRectSolid(0, 135, 0.0f, TOP_W, 105, C2D_Color32(230, 235, 242, 255));
        for (int i = 0; i < 8; i++) {
            C2D_DrawRectSolid(i * 50, 145 + (i % 2) * 35, 0.0f, 50, 35, C2D_Color32(185, 200, 220, 255));
        }
    }
}

// Render 3D Wearable Hat / Accessory on Meepa
static void render_3d_hat(int hat_id, float mx, float my, float mz) {
    float sx, sy, d;
    if (!project_pt(mx, my + 0.98f, mz, &sx, &sy, &d)) return;

    if (hat_id == 1) {
        // Royal Gold Crown
        u32 gold = C2D_Color32(255, 215, 35, 255);
        C2D_DrawRectSolid(sx - 24, sy - 10, 0.0f, 48, 12, gold);
        C2D_DrawTriangle(sx - 24, sy - 10, gold, sx - 12, sy - 26, gold, sx, sy - 10, gold, 0.0f);
        C2D_DrawTriangle(sx - 10, sy - 10, gold, sx, sy - 28, gold, sx + 10, sy - 10, gold, 0.0f);
        C2D_DrawTriangle(sx, sy - 10, gold, sx + 12, sy - 26, gold, sx + 24, sy - 10, gold, 0.0f);
        C2D_DrawCircleSolid(sx, sy - 16, 0.0f, 3.5f, C2D_Color32(235, 45, 60, 255));
    }
    else if (hat_id == 2) {
        // Classic Red & Black Top Hat
        C2D_DrawRectSolid(sx - 30, sy - 4, 0.0f, 60, 7, C2D_Color32(35, 35, 42, 255));
        C2D_DrawRectSolid(sx - 20, sy - 32, 0.0f, 40, 28, C2D_Color32(42, 42, 50, 255));
        C2D_DrawRectSolid(sx - 20, sy - 11, 0.0f, 40, 7, C2D_Color32(225, 45, 45, 255));
    }
    else if (hat_id == 3) {
        // Propeller Beanie Cap
        C2D_DrawEllipseSolid(sx - 24, sy - 14, 0.0f, 48, 20, C2D_Color32(55, 165, 245, 255));
        C2D_DrawRectSolid(sx - 2, sy - 22, 0.0f, 4, 10, C2D_Color32(240, 200, 30, 255));
        float blade_w = 22.0f * fabsf(cosf(s_anim_time * 8.0f)) + 6.0f;
        C2D_DrawRectSolid(sx - blade_w, sy - 24, 0.0f, blade_w * 2.0f, 4, C2D_Color32(245, 65, 55, 255));
    }
    else if (hat_id == 4) {
        // Pink Bowtie (worn on lower front of Meepa)
        float bx, by, bd;
        if (project_pt(mx, my - 0.58f, mz - 0.85f, &bx, &by, &bd)) {
            u32 pink = C2D_Color32(255, 105, 180, 255);
            C2D_DrawTriangle(bx - 18, by - 10, pink, bx - 18, by + 10, pink, bx, by, pink, 0.0f);
            C2D_DrawTriangle(bx + 18, by - 10, pink, bx + 18, by + 10, pink, bx, by, pink, 0.0f);
            C2D_DrawCircleSolid(bx, by, 0.0f, 5.0f, C2D_Color32(230, 70, 150, 255));
        }
    }
}

// Render 3D Food Item flying toward Meepa during feeding
static void render_3d_food_model(int food_id, float fx, float fy, float fz) {
    float sx, sy, d;
    if (!project_pt(fx, fy, fz, &sx, &sy, &d)) return;

    if (food_id == 0) {
        // 3D Red Apple with Leaf
        C2D_DrawCircleSolid(sx, sy, 0.0f, 14.0f, C2D_Color32(235, 45, 45, 255));
        C2D_DrawEllipseSolid(sx, sy - 16, 0.0f, 10, 6, C2D_Color32(75, 200, 75, 255));
    } else if (food_id == 1) {
        // 3D Pink Frosted Donut
        C2D_DrawCircleSolid(sx, sy, 0.0f, 16.0f, C2D_Color32(235, 180, 115, 255));
        C2D_DrawCircleSolid(sx, sy, 0.0f, 13.0f, C2D_Color32(255, 115, 185, 255));
        C2D_DrawCircleSolid(sx, sy, 0.0f, 5.0f, C2D_Color32(200, 200, 220, 255));
    } else if (food_id == 2) {
        // 3D Cheese Pizza Slice
        u32 crust = C2D_Color32(225, 155, 75, 255);
        u32 cheese = C2D_Color32(255, 215, 55, 255);
        C2D_DrawTriangle(sx - 16, sy - 12, crust, sx + 16, sy - 12, crust, sx, sy + 18, cheese, 0.0f);
        C2D_DrawCircleSolid(sx - 4, sy - 2, 0.0f, 4.0f, C2D_Color32(210, 45, 45, 255));
        C2D_DrawCircleSolid(sx + 5, sy + 3, 0.0f, 4.0f, C2D_Color32(210, 45, 45, 255));
    } else {
        // 3D Berry Soda Cup with Straw
        C2D_DrawRectSolid(sx - 10, sy - 12, 0.0f, 20, 26, C2D_Color32(65, 165, 250, 255));
        C2D_DrawRectSolid(sx - 12, sy - 14, 0.0f, 24, 5, C2D_Color32(255, 255, 255, 255));
        C2D_DrawRectSolid(sx + 2, sy - 22, 0.0f, 4, 10, C2D_Color32(245, 75, 95, 255));
    }
}

// Render the 3D Low-Poly Meepa Model with Animated Arms & Crisp ":3" Face
static void render_3d_meepa(float mx, float my, float mz, float yaw, float squash_y, float arm_angle) {
    // Floating ground shadow beneath Meepa (no legs, floats in air!)
    float shx, shy, shd;
    if (project_pt(mx, -0.95f, mz, &shx, &shy, &shd)) {
        float rw = 46.0f - (my + 0.1f) * 18.0f;
        C2D_DrawEllipseSolid(shx - rw, shy - 12, 0.0f, rw * 2.0f, 24.0f, C2D_Color32(20, 25, 35, 95));
    }

    float cy = cosf(yaw), sy_rot = sinf(yaw);
    float sx[MAX_VERTS], sy[MAX_VERTS], sz[MAX_VERTS];
    int valid[MAX_VERTS];

    for (int i = 0; i < s_vert_count; i++) {
        Vec3 v = s_base_verts[i];

        // Animate Left Arm (vertices 52..70) and Right Arm (vertices 71..89)
        if (i >= 52 && i <= 70) {
            // Pivot around left shoulder (-0.85, 0.15)
            float dy = v.y - 0.15f;
            float dx = v.x - (-0.85f);
            float ca = cosf(arm_angle), sa = sinf(arm_angle);
            v.x = -0.85f + (dx * ca - dy * sa);
            v.y =  0.15f + (dx * sa + dy * ca);
        } else if (i >= 71 && i <= 89) {
            // Pivot around right shoulder (+0.85, 0.15)
            float dy = v.y - 0.15f;
            float dx = v.x - 0.85f;
            float ca = cosf(-arm_angle), sa = sinf(-arm_angle);
            v.x = 0.85f + (dx * ca - dy * sa);
            v.y = 0.15f + (dx * sa + dy * ca);
        }

        // Apply squash & stretch
        v.y *= squash_y;
        v.x *= (2.0f - squash_y) * 0.5f + 0.5f;

        // Rotate by yaw around Y axis
        float rx = v.x * cy + v.z * sy_rot;
        float ry = v.y;
        float rz = -v.x * sy_rot + v.z * cy;

        valid[i] = project_pt(mx + rx, my + ry, mz - rz * 0.85f, &sx[i], &sy[i], &sz[i]);
    }

    // Painter's Algorithm Depth Sort
    int order[MAX_FACES];
    int count = 0;
    for (int i = 0; i < s_face_count; i++) {
        FaceQuad* fq = &s_faces[i];
        if (!valid[fq->v[0]] || !valid[fq->v[1]] || !valid[fq->v[2]] || !valid[fq->v[3]]) continue;
        fq->avg_z = (sz[fq->v[0]] + sz[fq->v[1]] + sz[fq->v[2]] + sz[fq->v[3]]) * 0.25f;

        // Soft studio shading so pure white Meepa looks 3D and chunky
        float ny = s_base_verts[fq->v[0]].y;
        fq->shade = 0.90f + 0.10f * (ny > 0.0f ? ny : 0.0f);
        order[count++] = i;
    }

    for (int i = 1; i < count; i++) {
        int key = order[i];
        float kz = s_faces[key].avg_z;
        int j = i - 1;
        while (j >= 0 && s_faces[order[j]].avg_z < kz) {
            order[j + 1] = order[j];
            j--;
        }
        order[j + 1] = key;
    }

    for (int idx = 0; idx < count; idx++) {
        FaceQuad* fq = &s_faces[order[idx]];
        int v0 = fq->v[0], v1 = fq->v[1], v2 = fq->v[2], v3 = fq->v[3];
        int cval = (int)(242.0f + fq->shade * 13.0f);
        if (cval > 255) cval = 255;
        u32 white_col = C2D_Color32(cval, cval, 255, 255);

        C2D_DrawTriangle(sx[v0], sy[v0], white_col, sx[v1], sy[v1], white_col, sx[v2], sy[v2], white_col, 0.0f);
        if (v3 != v2) {
            C2D_DrawTriangle(sx[v0], sy[v0], white_col, sx[v2], sy[v2], white_col, sx[v3], sy[v3], white_col, 0.0f);
        }
    }

    // Project Meepa's iconic crisp ":3" pixel face onto the front of the 3D sphere!
    if (cosf(yaw) > -0.25f) {
        float fx_off = sinf(yaw) * 0.85f;
        float f_sx, f_sy, f_d;
        if (project_pt(mx + fx_off, my + 0.08f, mz - 0.92f, &f_sx, &f_sy, &f_d)) {
            u32 ink = C2D_Color32(18, 18, 22, 255);
            if (s_action == ACT_SLEEPING) {
                // Sleeping "-  -" eyes
                C2D_DrawRectSolid(f_sx - 24, f_sy - 8, 0.0f, 12, 4, ink);
                C2D_DrawRectSolid(f_sx + 12, f_sy - 8, 0.0f, 12, 4, ink);
            } else {
                // Crisp square pixel eyes from meepa_clean_face.png
                C2D_DrawRectSolid(f_sx - 22, f_sy - 14, 0.0f, 10, 10, ink);
                C2D_DrawRectSolid(f_sx + 12, f_sy - 14, 0.0f, 10, 10, ink);
            }
            // Rosy blush cheeks when happy!
            if (s_happy_timer > 0 || s_stat_happy > 80.0f) {
                C2D_DrawEllipseSolid(f_sx - 30, f_sy - 1, 0.0f, 10, 6, C2D_Color32(255, 150, 175, 190));
                C2D_DrawEllipseSolid(f_sx + 20, f_sy - 1, 0.0f, 10, 6, C2D_Color32(255, 150, 175, 190));
            }
            // Iconic pixel ":3" cat mouth!
            C2D_DrawRectSolid(f_sx - 10, f_sy + 6,  0.0f, 8, 4, ink);
            C2D_DrawRectSolid(f_sx + 2,  f_sy + 6,  0.0f, 8, 4, ink);
            C2D_DrawRectSolid(f_sx - 13, f_sy + 3,  0.0f, 4, 4, ink);
            C2D_DrawRectSolid(f_sx - 2,  f_sy + 2,  0.0f, 4, 5, ink);
            C2D_DrawRectSolid(f_sx + 9,  f_sy + 3,  0.0f, 4, 4, ink);
        }
    }

    // Render Equipped 3D Hat on top of Meepa
    render_3d_hat(s_equipped_hat, mx, my, mz);
}

static void draw_btn(int x, int y, int w, int h, u32 fill, int active) {
    u32 border = active ? C2D_Color32(255, 225, 45, 255) : C2D_Color32(90, 105, 130, 255);
    C2D_DrawRectSolid(x, y, 0.0f, w, h, border);
    C2D_DrawRectSolid(x + 2, y + 2, 0.0f, w - 4, h - 4, fill);
}

static int hit_box(touchPosition tp, int x, int y, int w, int h) {
    return (tp.px >= x && tp.px <= (x + w) && tp.py >= y && tp.py <= (y + h));
}

int main(int argc, char* argv[]) {
    gfxInitDefault();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    s_text_buf = C2D_TextBufNew(4096);

    C3D_RenderTarget* topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget* botTarget = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    load_meepa_obj("romfs:/meepa.obj");
    init_meepa_audio();

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();
        touchPosition touch;
        hidTouchRead(&touch);
        circlePosition cpos;
        hidCircleRead(&cpos);

        if (kDown & KEY_START) break;

        s_anim_time += 1.0f / 60.0f;

        // Gradual stat decay over time
        s_stat_hunger  -= 0.004f;
        s_stat_happy   -= 0.003f;
        s_stat_hygiene -= 0.003f;
        if (s_action == ACT_SLEEPING) {
            s_stat_energy += 0.08f;
            if (s_stat_energy > 100.0f) s_stat_energy = 100.0f;
        } else {
            s_stat_energy -= 0.003f;
        }
        if (s_stat_hunger < 0.0f)  s_stat_hunger = 0.0f;
        if (s_stat_happy < 0.0f)   s_stat_happy = 0.0f;
        if (s_stat_hygiene < 0.0f) s_stat_hygiene = 0.0f;
        if (s_stat_energy < 0.0f)  s_stat_energy = 0.0f;

        // Rotate Meepa with L/R or Circle Pad
        s_meepa_rot += (cpos.dx / 155.0f) * 0.06f;
        if (kHeld & KEY_L) s_meepa_rot -= 0.05f;
        if (kHeld & KEY_R) s_meepa_rot += 0.05f;
        if (!(kHeld & (KEY_L | KEY_R)) && abs(cpos.dx) < 20) {
            s_meepa_rot *= 0.92f;
        }

        // Pet Meepa by pressing A or tapping center
        if ((kDown & KEY_A) && s_action == ACT_IDLE_CARE) {
            s_stat_happy = (s_stat_happy + 8.0f > 100.0f) ? 100.0f : s_stat_happy + 8.0f;
            s_happy_timer = 55;
            s_meepa_coins += 5;
            s_status_msg = "Meepa purrs happily! :3 (+5 Coins)";
            spawn_particles(C2D_Color32(255, 95, 155, 255), 8);
        }

        // Handle Touch Dashboard Buttons
        if (kDown & KEY_TOUCH) {
            // Top Row: 6 Main Care Action Buttons
            if (hit_box(touch, 10, 12, 95, 36)) {
                s_action = ACT_FEEDING;
                s_status_msg = "Pick a tasty 3D treat to feed Meepa!";
            } else if (hit_box(touch, 112, 12, 95, 36)) {
                s_action = ACT_WARDROBE;
                s_status_msg = "Dress up Meepa with 3D hats & bows!";
            } else if (hit_box(touch, 214, 12, 95, 36)) {
                s_action = ACT_BATH_SCRUB;
                s_status_msg = "Hold A or drag stylus to scrub Meepa clean!";
            } else if (hit_box(touch, 10, 54, 95, 36)) {
                s_action = (s_action == ACT_SLEEPING) ? ACT_IDLE_CARE : ACT_SLEEPING;
                s_status_msg = (s_action == ACT_SLEEPING) ? "Shhh... Meepa is napping (- _ -)" : "Meepa woke up refreshed! :3";
            } else if (hit_box(touch, 112, 54, 95, 36)) {
                s_action = ACT_MINIGAME;
                s_rally_score = 0;
                s_status_msg = "Bounce the 3D Ball with D-Pad / Circle Pad!";
            } else if (hit_box(touch, 214, 54, 95, 36)) {
                s_action = ACT_IDLE_CARE;
                s_stat_happy = (s_stat_happy + 10.0f > 100.0f) ? 100.0f : s_stat_happy + 10.0f;
                s_happy_timer = 60;
                s_meepa_coins += 5;
                s_status_msg = "You gave Meepa a big hug! :3 (+5 Coins)";
                spawn_particles(C2D_Color32(255, 105, 180, 255), 10);
            }

            // Sub-panel interactions (Middle of Bottom Screen)
            if (s_action == ACT_FEEDING) {
                if (hit_box(touch, 15, 105, 65, 42))  s_selected_food = (s_selected_food + 3) % 4;
                if (hit_box(touch, 240, 105, 65, 42)) s_selected_food = (s_selected_food + 1) % 4;
                if (hit_box(touch, 90, 105, 140, 42)) {
                    if (s_food_counts[s_selected_food] > 0) {
                        s_food_counts[s_selected_food]--;
                        s_food_timer = 45;
                        s_stat_hunger = (s_stat_hunger + 25.0f > 100.0f) ? 100.0f : s_stat_hunger + 25.0f;
                        s_stat_happy  = (s_stat_happy + 10.0f > 100.0f) ? 100.0f : s_stat_happy + 10.0f;
                        s_happy_timer = 60;
                        s_status_msg = "Yum! Meepa loved the snack! :3";
                        spawn_particles(C2D_Color32(255, 215, 45, 255), 12);
                    } else {
                        s_status_msg = "Out of stock! Visit Meepa Store to buy more!";
                    }
                }
            }
            else if (s_action == ACT_WARDROBE) {
                if (hit_box(touch, 15, 105, 65, 42))  s_equipped_hat = (s_equipped_hat + 4) % 5;
                if (hit_box(touch, 240, 105, 65, 42)) s_equipped_hat = (s_equipped_hat + 1) % 5;
                if (hit_box(touch, 90, 105, 140, 42)) {
                    if (!s_owned_hats[s_equipped_hat]) {
                        if (s_meepa_coins >= s_hat_prices[s_equipped_hat]) {
                            s_meepa_coins -= s_hat_prices[s_equipped_hat];
                            s_owned_hats[s_equipped_hat] = 1;
                            s_status_msg = "Unlocked new 3D Hat for Meepa! :3";
                            spawn_particles(C2D_Color32(100, 255, 150, 255), 12);
                        } else {
                            s_status_msg = "Need more Meepa Coins! Play Ball in the Park!";
                        }
                    } else {
                        s_status_msg = "Meepa looks super stylish! :3";
                    }
                }
            }
            else if (s_location == LOC_MEEPA_STORE) {
                // Buy food pack in store
                if (hit_box(touch, 40, 105, 240, 42)) {
                    int price = s_food_prices[s_selected_food];
                    if (s_meepa_coins >= price) {
                        s_meepa_coins -= price;
                        s_food_counts[s_selected_food] += 2;
                        s_status_msg = "Bought +2 Food Pack at Meepa Mart!";
                        spawn_particles(C2D_Color32(80, 235, 255, 255), 8);
                    } else {
                        s_status_msg = "Not enough Coins! Play with Meepa to earn more!";
                    }
                }
            }

            // Bottom Row: Travel Between 3 Locations (House, Outside Park, Store)
            if (hit_box(touch, 10, 192, 95, 38)) {
                s_location = LOC_HOUSE_INSIDE;
                s_status_msg = "Welcome home to Meepa's Cozy House!";
            } else if (hit_box(touch, 112, 192, 95, 38)) {
                s_location = LOC_OUTSIDE_PARK;
                s_status_msg = "Outside at Meepa Park! Fresh air & sunshine!";
            } else if (hit_box(touch, 214, 192, 95, 38)) {
                s_location = LOC_MEEPA_STORE;
                s_action = ACT_FEEDING;
                s_status_msg = "Welcome to Meepa Mart! Tap food to restock!";
            }
        }

        // Bath Scrubbing Logic
        if (s_action == ACT_BATH_SCRUB && ((kHeld & KEY_A) || (kHeld & KEY_TOUCH))) {
            s_stat_hygiene += 0.35f;
            if (s_stat_hygiene >= 100.0f) {
                s_stat_hygiene = 100.0f;
                s_status_msg = "Sparkling clean! Meepa is super fresh! :3";
            }
            if ((rand() % 4) == 0) {
                spawn_particles(C2D_Color32(165, 235, 255, 235), 2);
            }
        }

        // Mini-game Ball Bounce Logic
        if (s_action == ACT_MINIGAME) {
            s_ball_x += s_ball_vx;
            s_ball_z += s_ball_vz;
            if (s_ball_x < -1.4f || s_ball_x > 1.4f) s_ball_vx = -s_ball_vx;
            if (s_ball_z > 5.0f) {
                // Meepa hits the ball back!
                s_ball_vz = -fabsf(s_ball_vz);
                s_happy_timer = 20;
            }
            if (s_ball_z < 2.2f) {
                // Player bounces ball back
                s_ball_vz = fabsf(s_ball_vz);
                s_rally_score++;
                s_meepa_coins += 5;
                s_stat_happy = (s_stat_happy + 4.0f > 100.0f) ? 100.0f : s_stat_happy + 4.0f;
                spawn_particles(C2D_Color32(255, 230, 65, 255), 5);
            }
        }

        // Compute Meepa procedural floating & arm wave pose
        s_meepa_bob = sinf(s_anim_time * 3.2f) * 0.12f;
        float squash = 1.0f + sinf(s_anim_time * 3.2f) * 0.04f;
        if (s_happy_timer > 0) {
            s_happy_timer--;
            s_arm_wave = sinf(s_anim_time * 16.0f) * 0.55f + 0.35f;
            squash = 1.0f + sinf(s_anim_time * 12.0f) * 0.09f;
        } else if (s_action == ACT_SLEEPING) {
            s_meepa_bob = -0.25f + sinf(s_anim_time * 1.4f) * 0.04f;
            s_arm_wave = -0.35f;
        } else {
            s_arm_wave = sinf(s_anim_time * 2.5f) * 0.15f;
        }

        if (s_food_timer > 0) s_food_timer--;

        // Update particles
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (s_particles[i].life > 0) {
                s_particles[i].y += s_particles[i].vy;
                s_particles[i].life--;
            }
        }

        // ================= RENDER DUAL SCREENS =================
        C2D_TextBufClear(s_text_buf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        // --- TOP SCREEN (400x240 3D MEEPA WORLD) ---
        C2D_TargetClear(topTarget, C2D_Color32(30, 35, 45, 255));
        C2D_SceneBegin(topTarget);

        render_3d_environment(s_location);

        // Render 3D Low-Poly Meepa in center of room/park
        render_3d_meepa(0.0f, s_meepa_bob, 4.3f, s_meepa_rot, squash, s_arm_wave);

        // Render 3D Flying Food if feeding
        if (s_food_timer > 0) {
            float t = (float)s_food_timer / 45.0f;
            render_3d_food_model(s_selected_food, 0.0f, -0.4f + (1.0f - t) * 0.4f, 2.2f + (1.0f - t) * 1.6f);
        }

        // Render 3D Beach Ball if in Mini-Game
        if (s_action == ACT_MINIGAME) {
            float bsx, bsy, bd;
            if (project_pt(s_ball_x, fabs(sinf(s_anim_time * 6.0f)) * 0.55f - 0.3f, s_ball_z, &bsx, &bsy, &bd)) {
                float rad = 42.0f / bd;
                C2D_DrawCircleSolid(bsx, bsy, 0.0f, rad, C2D_Color32(255, 85, 75, 255));
                C2D_DrawCircleSolid(bsx - rad*0.3f, bsy - rad*0.3f, 0.0f, rad*0.45f, C2D_Color32(255, 235, 85, 255));
            }
        }

        // Render Floating 3D Particles (Hearts, Bubbles, Stars)
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (s_particles[i].life > 0) {
                float px, py, pd;
                if (project_pt(s_particles[i].x, s_particles[i].y, s_particles[i].z, &px, &py, &pd)) {
                    C2D_DrawCircleSolid(px, py, 0.0f, 5.5f, s_particles[i].color);
                }
            }
        }

        // Top HUD Status Bar (4 Pet Care Meters + Coins)
        C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, 30, C2D_Color32(20, 24, 34, 215));
        const char* labels[4] = {"HUNGER", "HAPPY", "ENERGY", "CLEAN"};
        float vals[4] = {s_stat_hunger, s_stat_happy, s_stat_energy, s_stat_hygiene};
        u32 cols[4] = {
            C2D_Color32(255, 145, 55, 255),
            C2D_Color32(255, 95, 165, 255),
            C2D_Color32(255, 220, 55, 255),
            C2D_Color32(75, 210, 255, 255)
        };
        for (int m = 0; m < 4; m++) {
            int bx = 8 + m * 76;
            draw_label(bx, 2, 0.38f, C2D_Color32(230, 235, 245, 255), labels[m]);
            C2D_DrawRectSolid(bx, 16, 0.0f, 66, 9, C2D_Color32(50, 55, 70, 255));
            C2D_DrawRectSolid(bx + 1, 17, 0.0f, 64.0f * (vals[m] / 100.0f), 7, cols[m]);
        }
        char coin_buf[32];
        snprintf(coin_buf, sizeof(coin_buf), "COINS: %d", s_meepa_coins);
        draw_label(316, 8, 0.45f, C2D_Color32(255, 225, 55, 255), coin_buf);

        // Bottom Banner on Top Screen
        C2D_DrawRectSolid(0, 214, 0.0f, TOP_W, 26, C2D_Color32(20, 24, 34, 210));
        draw_label(12, 219, 0.46f, C2D_Color32(255, 255, 255, 255), s_status_msg);

        // --- BOTTOM SCREEN (320x240 CARE & TRAVEL TOUCH CONSOLE) ---
        C2D_TargetClear(botTarget, C2D_Color32(28, 32, 44, 255));
        C2D_SceneBegin(botTarget);

        // Row 1 & 2: 6 Care Action Buttons
        draw_btn(10,  12, 95, 36, C2D_Color32(225, 95, 55, 255),  s_action == ACT_FEEDING);
        draw_btn(112, 12, 95, 36, C2D_Color32(155, 85, 225, 255), s_action == ACT_WARDROBE);
        draw_btn(214, 12, 95, 36, C2D_Color32(55, 175, 235, 255), s_action == ACT_BATH_SCRUB);

        draw_btn(10,  54, 95, 36, C2D_Color32(75, 95, 175, 255),  s_action == ACT_SLEEPING);
        draw_btn(112, 54, 95, 36, C2D_Color32(65, 195, 95, 255),  s_action == ACT_MINIGAME);
        draw_btn(214, 54, 95, 36, C2D_Color32(235, 95, 155, 255), s_action == ACT_IDLE_CARE);

        draw_label(24,  22, 0.46f, C2D_Color32(255,255,255,255), "FEED MEEPA");
        draw_label(124, 22, 0.46f, C2D_Color32(255,255,255,255), "3D CLOTHES");
        draw_label(226, 22, 0.46f, C2D_Color32(255,255,255,255), "SCRUB BATH");
        draw_label(26,  64, 0.46f, C2D_Color32(255,255,255,255), "NAP / SLEEP");
        draw_label(124, 64, 0.46f, C2D_Color32(255,255,255,255), "PLAY CATCH");
        draw_label(226, 64, 0.46f, C2D_Color32(255,255,255,255), "PET MEEPA");

        // Context Tray (Middle of Bottom Screen)
        C2D_DrawRectSolid(10, 98, 0.0f, 300, 84, C2D_Color32(20, 23, 32, 255));
        if (s_action == ACT_FEEDING) {
            draw_btn(15,  105, 65, 42, C2D_Color32(60, 70, 95, 255), 0);
            draw_btn(90,  105, 140, 42, C2D_Color32(45, 185, 85, 255), 1);
            draw_btn(240, 105, 65, 42, C2D_Color32(60, 70, 95, 255), 0);
            draw_label(28,  118, 0.48f, C2D_Color32(255,255,255,255), "< PREV");
            draw_label(252, 118, 0.48f, C2D_Color32(255,255,255,255), "NEXT >");

            char fbuf[64];
            if (s_location == LOC_MEEPA_STORE) {
                snprintf(fbuf, sizeof(fbuf), "BUY %s (%dG)", s_food_names[s_selected_food], s_food_prices[s_selected_food]);
            } else {
                snprintf(fbuf, sizeof(fbuf), "EAT %s (x%d)", s_food_names[s_selected_food], s_food_counts[s_selected_food]);
            }
            draw_label(98, 118, 0.44f, C2D_Color32(255,255,255,255), fbuf);
            draw_label(35, 156, 0.42f, C2D_Color32(190, 210, 240, 255), "Tip: Visit MEEPA STORE below to restock snacks!");
        }
        else if (s_action == ACT_WARDROBE) {
            draw_btn(15,  105, 65, 42, C2D_Color32(60, 70, 95, 255), 0);
            draw_btn(90,  105, 140, 42, C2D_Color32(155, 85, 215, 255), 1);
            draw_btn(240, 105, 65, 42, C2D_Color32(60, 70, 95, 255), 0);
            draw_label(28,  118, 0.48f, C2D_Color32(255,255,255,255), "< PREV");
            draw_label(252, 118, 0.48f, C2D_Color32(255,255,255,255), "NEXT >");

            char hbuf[64];
            if (s_owned_hats[s_equipped_hat]) {
                snprintf(hbuf, sizeof(hbuf), "WEARING: %s", s_hat_names[s_equipped_hat]);
            } else {
                snprintf(hbuf, sizeof(hbuf), "BUY %s (%dG)", s_hat_names[s_equipped_hat], s_hat_prices[s_equipped_hat]);
            }
            draw_label(96, 118, 0.42f, C2D_Color32(255,255,255,255), hbuf);
            draw_label(42, 156, 0.42f, C2D_Color32(200, 215, 240, 255), "Use L/R or Circle Pad to spin Meepa 360 degrees!");
        }
        else {
            draw_label(25, 115, 0.46f, C2D_Color32(255, 230, 85, 255), "MEEPA CARE CONTROLS:");
            draw_label(25, 136, 0.42f, C2D_Color32(220, 230, 245, 255), "- Press A or tap buttons to care for Meepa");
            draw_label(25, 154, 0.42f, C2D_Color32(220, 230, 245, 255), "- Circle Pad / L & R: Rotate 3D Meepa Camera");
        }

        // Bottom Row: 3 World Locations (Inside House, Outside Park, Store)
        draw_btn(10,  192, 95, 38, C2D_Color32(185, 115, 65, 255), s_location == LOC_HOUSE_INSIDE);
        draw_btn(112, 192, 95, 38, C2D_Color32(65, 175, 85, 255),  s_location == LOC_OUTSIDE_PARK);
        draw_btn(214, 192, 95, 38, C2D_Color32(55, 135, 215, 255), s_location == LOC_MEEPA_STORE);

        draw_label(22,  203, 0.45f, C2D_Color32(255,255,255,255), "INSIDE HOUSE");
        draw_label(122, 203, 0.45f, C2D_Color32(255,255,255,255), "OUTSIDE PARK");
        draw_label(224, 203, 0.45f, C2D_Color32(255,255,255,255), "MEEPA STORE");

        C3D_FrameEnd(0);
    }

    if (s_ndsp_ready) {
        ndspChnReset(0);
        ndspExit();
    }
    if (s_audio_buf) linearFree(s_audio_buf);
    C2D_TextBufDelete(s_text_buf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
